const pool = require('../config/database');

/**
 * COMPREHENSIVE ANALYSIS SERVICE
 * Implements all 14 elements from SKILL4-ANALYSIS.md
 */

// ==================== UTILITY FUNCTIONS ====================

/**
 * Build WHERE clause from filters
 */
function buildWhereClause(filters) {
  const conditions = [];
  const params = [];
  let paramIndex = 1;

  if (filters.province) {
    conditions.push(`recipient_province = $${paramIndex++}`);
    params.push(filters.province);
  }

  if (filters.agreement_type) {
    conditions.push(`agreement_type = $${paramIndex++}`);
    params.push(filters.agreement_type);
  }

  if (filters.start_date_from) {
    conditions.push(`agreement_start_date >= $${paramIndex++}`);
    params.push(filters.start_date_from);
  }

  if (filters.start_date_to) {
    conditions.push(`agreement_start_date <= $${paramIndex++}`);
    params.push(filters.start_date_to);
  }

  if (filters.end_date_from) {
    conditions.push(`agreement_end_date >= $${paramIndex++}`);
    params.push(filters.end_date_from);
  }

  if (filters.end_date_to) {
    conditions.push(`agreement_end_date <= $${paramIndex++}`);
    params.push(filters.end_date_to);
  }

  if (filters.value_min) {
    conditions.push(`agreement_value >= $${paramIndex++}`);
    params.push(filters.value_min);
  }

  if (filters.value_max) {
    conditions.push(`agreement_value <= $${paramIndex++}`);
    params.push(filters.value_max);
  }

  if (filters.city) {
    conditions.push(`recipient_city ILIKE $${paramIndex++}`);
    params.push(`%${filters.city}%`);
  }

  if (filters.program) {
    conditions.push(`prog_name_en ILIKE $${paramIndex++}`);
    params.push(`%${filters.program}%`);
  }

  if (filters.recipient_type) {
    conditions.push(`recipient_type = $${paramIndex++}`);
    params.push(filters.recipient_type);
  }

  if (filters.owner_org) {
    conditions.push(`owner_org_title = $${paramIndex++}`);
    params.push(filters.owner_org);
  }

  if (filters.federal_riding) {
    conditions.push(`federal_riding_name_en = $${paramIndex++}`);
    params.push(filters.federal_riding);
  }

  const whereClause = conditions.length > 0 ? `WHERE ${conditions.join(' AND ')}` : '';
  return { whereClause, params };
}

/**
 * Derive fiscal year from date (April 1 - March 31)
 */
function getFiscalYear(dateStr) {
  if (!dateStr) return null;
  const date = new Date(dateStr);
  const year = date.getFullYear();
  const month = date.getMonth() + 1;
  return month >= 4 ? year : year - 1;
}

/**
 * Derive fiscal quarter (Q1: Apr-Jun, Q2: Jul-Sep, Q3: Oct-Dec, Q4: Jan-Mar)
 */
function getFiscalQuarter(dateStr) {
  if (!dateStr) return null;
  const date = new Date(dateStr);
  const month = date.getMonth() + 1;
  if (month >= 4 && month <= 6) return 'Q1';
  if (month >= 7 && month <= 9) return 'Q2';
  if (month >= 10 && month <= 12) return 'Q3';
  return 'Q4';
}

/**
 * Classify value tier
 */
function getValueTier(value) {
  if (value < 25000) return 'Micro';
  if (value < 100000) return 'Small';
  if (value < 500000) return 'Medium';
  if (value < 1000000) return 'Large';
  if (value < 5000000) return 'Major';
  return 'Mega';
}

// ==================== 1. EXECUTIVE DASHBOARD KPIs ====================

/**
 * Get executive dashboard KPIs
 */
exports.getDashboardKPIs = async (filters = {}) => {
  const { whereClause, params } = buildWhereClause(filters);

  const query = `
    SELECT
      COUNT(*) as total_agreements,
      COUNT(DISTINCT recipient_legal_name) as unique_recipients,
      SUM(agreement_value) as total_funding,
      AVG(agreement_value) as average_value,
      MAX(agreement_value) as max_value,
      MIN(agreement_value) as min_value,
      COUNT(DISTINCT prog_name_en) as program_count,
      COUNT(DISTINCT owner_org_title) as department_count,
      COUNT(DISTINCT federal_riding_name_en) as riding_count,
      COUNT(CASE WHEN amendment_number IS NOT NULL AND amendment_number != '' AND amendment_number != '0' THEN 1 END) as amended_count,
      COUNT(CASE WHEN agreement_start_date IS NOT NULL
            AND agreement_end_date IS NOT NULL
            AND CURRENT_DATE BETWEEN agreement_start_date::date AND agreement_end_date::date
            THEN 1 END) as active_agreements
    FROM grants_contributions
    ${whereClause}
  `;

  const result = await pool.query(query, params);
  const kpis = result.rows[0];

  // Calculate amendment rate
  const amendmentRate = kpis.total_agreements > 0
    ? (parseInt(kpis.amended_count) / parseInt(kpis.total_agreements)) * 100
    : 0;

  return {
    total_agreements: parseInt(kpis.total_agreements),
    unique_recipients: parseInt(kpis.unique_recipients),
    total_funding: parseFloat(kpis.total_funding) || 0,
    average_value: parseFloat(kpis.average_value) || 0,
    max_value: parseFloat(kpis.max_value) || 0,
    min_value: parseFloat(kpis.min_value) || 0,
    program_count: parseInt(kpis.program_count),
    department_count: parseInt(kpis.department_count),
    riding_count: parseInt(kpis.riding_count),
    active_agreements: parseInt(kpis.active_agreements),
    amendment_rate: amendmentRate.toFixed(2)
  };
};

// ==================== 2. FINANCIAL ANALYSIS ====================

/**
 * Get comprehensive financial analysis
 */
exports.getFinancialAnalysis = async (filters = {}) => {
  const { whereClause, params } = buildWhereClause(filters);

  // Overall statistics
  const statsQuery = `
    SELECT
      COUNT(*) as total_count,
      SUM(agreement_value) as total_value,
      AVG(agreement_value) as average_value,
      STDDEV(agreement_value) as stddev_value,
      PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY agreement_value) as median_value,
      PERCENTILE_CONT(0.25) WITHIN GROUP (ORDER BY agreement_value) as q1_value,
      PERCENTILE_CONT(0.75) WITHIN GROUP (ORDER BY agreement_value) as q3_value,
      MAX(agreement_value) as max_value,
      MIN(agreement_value) as min_value
    FROM grants_contributions
    ${whereClause}
  `;

  // Value tier distribution
  const tierQuery = `
    SELECT
      CASE
        WHEN agreement_value < 25000 THEN 'Micro'
        WHEN agreement_value < 100000 THEN 'Small'
        WHEN agreement_value < 500000 THEN 'Medium'
        WHEN agreement_value < 1000000 THEN 'Large'
        WHEN agreement_value < 5000000 THEN 'Major'
        ELSE 'Mega'
      END as tier,
      COUNT(*) as count,
      SUM(agreement_value) as total_value,
      AVG(agreement_value) as avg_value
    FROM grants_contributions
    ${whereClause}
    GROUP BY tier
    ORDER BY MIN(agreement_value)
  `;

  // Agreement type distribution
  const typeQuery = `
    SELECT
      agreement_type,
      COUNT(*) as count,
      SUM(agreement_value) as total_value,
      AVG(agreement_value) as avg_value
    FROM grants_contributions
    ${whereClause}
    GROUP BY agreement_type
    ORDER BY total_value DESC
  `;

  // Top recipients by funding
  const topRecipientsQuery = `
    SELECT
      recipient_legal_name,
      COUNT(*) as agreement_count,
      SUM(agreement_value) as total_value,
      AVG(agreement_value) as avg_value,
      MIN(agreement_start_date) as first_agreement,
      MAX(agreement_start_date) as latest_agreement
    FROM grants_contributions
    ${whereClause}
    GROUP BY recipient_legal_name
    ORDER BY total_value DESC
    LIMIT 20
  `;

  // Funding concentration (HHI calculation)
  const concentrationQuery = `
    WITH recipient_shares AS (
      SELECT
        recipient_legal_name,
        SUM(agreement_value) as recipient_total,
        (SUM(agreement_value) / (SELECT SUM(agreement_value) FROM grants_contributions ${whereClause})) * 100 as share_pct
      FROM grants_contributions
      ${whereClause}
      GROUP BY recipient_legal_name
    )
    SELECT
      SUM(POWER(share_pct, 2)) as hhi_index,
      COUNT(*) as recipient_count,
      SUM(CASE WHEN share_pct > 5 THEN 1 ELSE 0 END) as concentrated_recipients,
      (SELECT SUM(recipient_total) FROM (SELECT recipient_total FROM recipient_shares ORDER BY recipient_total DESC LIMIT 10) top10) as top_10_total,
      (SELECT SUM(agreement_value) FROM grants_contributions ${whereClause}) as overall_total
    FROM recipient_shares
  `;

  // Round number detection
  const roundNumberQuery = `
    SELECT
      COUNT(CASE WHEN agreement_value % 100000 = 0 THEN 1 END) as round_100k,
      COUNT(CASE WHEN agreement_value % 50000 = 0 THEN 1 END) as round_50k,
      COUNT(CASE WHEN agreement_value = 24999 THEN 1 END) as threshold_24999,
      COUNT(CASE WHEN agreement_value = 99999 THEN 1 END) as threshold_99999,
      COUNT(CASE WHEN agreement_value = 499999 THEN 1 END) as threshold_499999,
      COUNT(*) as total
    FROM grants_contributions
    ${whereClause}
  `;

  const [statsResult, tierResult, typeResult, topRecipientsResult, concentrationResult, roundNumberResult] = await Promise.all([
    pool.query(statsQuery, params),
    pool.query(tierQuery, params),
    pool.query(typeQuery, params),
    pool.query(topRecipientsQuery, params),
    pool.query(concentrationQuery, params),
    pool.query(roundNumberQuery, params)
  ]);

  const stats = statsResult.rows[0];
  const concentration = concentrationResult.rows[0];

  // Calculate concentration ratio
  const top10Share = concentration.overall_total > 0
    ? (parseFloat(concentration.top_10_total) / parseFloat(concentration.overall_total)) * 100
    : 0;

  return {
    overview: {
      total_count: parseInt(stats.total_count),
      total_value: parseFloat(stats.total_value) || 0,
      average_value: parseFloat(stats.average_value) || 0,
      median_value: parseFloat(stats.median_value) || 0,
      stddev_value: parseFloat(stats.stddev_value) || 0,
      q1_value: parseFloat(stats.q1_value) || 0,
      q3_value: parseFloat(stats.q3_value) || 0,
      max_value: parseFloat(stats.max_value) || 0,
      min_value: parseFloat(stats.min_value) || 0,
      mean_median_ratio: stats.median_value > 0 ? parseFloat(stats.average_value) / parseFloat(stats.median_value) : 0
    },
    by_tier: tierResult.rows.map(row => ({
      tier: row.tier,
      count: parseInt(row.count),
      total_value: parseFloat(row.total_value),
      avg_value: parseFloat(row.avg_value)
    })),
    by_type: typeResult.rows.map(row => ({
      agreement_type: row.agreement_type,
      count: parseInt(row.count),
      total_value: parseFloat(row.total_value),
      avg_value: parseFloat(row.avg_value)
    })),
    top_recipients: topRecipientsResult.rows.map(row => ({
      recipient_legal_name: row.recipient_legal_name,
      agreement_count: parseInt(row.agreement_count),
      total_value: parseFloat(row.total_value),
      avg_value: parseFloat(row.avg_value),
      first_agreement: row.first_agreement,
      latest_agreement: row.latest_agreement
    })),
    concentration: {
      hhi_index: parseFloat(concentration.hhi_index) || 0,
      recipient_count: parseInt(concentration.recipient_count),
      concentrated_recipients: parseInt(concentration.concentrated_recipients),
      top_10_share: top10Share,
      concentration_level: parseFloat(concentration.hhi_index) > 2500 ? 'High' : parseFloat(concentration.hhi_index) > 1500 ? 'Moderate' : 'Low'
    },
    anomalies: {
      round_100k: parseInt(roundNumberResult.rows[0].round_100k),
      round_50k: parseInt(roundNumberResult.rows[0].round_50k),
      threshold_24999: parseInt(roundNumberResult.rows[0].threshold_24999),
      threshold_99999: parseInt(roundNumberResult.rows[0].threshold_99999),
      threshold_499999: parseInt(roundNumberResult.rows[0].threshold_499999),
      total: parseInt(roundNumberResult.rows[0].total)
    }
  };
};

// ==================== 3. TEMPORAL ANALYSIS ====================

/**
 * Get comprehensive temporal analysis
 */
exports.getTemporalAnalysis = async (filters = {}) => {
  const { whereClause, params } = buildWhereClause(filters);

  // Fiscal year analysis
  const fiscalYearQuery = `
    SELECT
      CASE
        WHEN EXTRACT(MONTH FROM agreement_start_date::date) >= 4
        THEN EXTRACT(YEAR FROM agreement_start_date::date)
        ELSE EXTRACT(YEAR FROM agreement_start_date::date) - 1
      END as fiscal_year,
      COUNT(*) as count,
      SUM(agreement_value) as total_value,
      AVG(agreement_value) as avg_value
    FROM grants_contributions
    ${whereClause}
    AND agreement_start_date IS NOT NULL
    GROUP BY fiscal_year
    ORDER BY fiscal_year DESC
  `;

  // Quarterly analysis (fiscal quarters)
  const quarterQuery = `
    SELECT
      CASE
        WHEN EXTRACT(MONTH FROM agreement_start_date::date) >= 4
        THEN EXTRACT(YEAR FROM agreement_start_date::date)
        ELSE EXTRACT(YEAR FROM agreement_start_date::date) - 1
      END as fiscal_year,
      CASE
        WHEN EXTRACT(MONTH FROM agreement_start_date::date) IN (4, 5, 6) THEN 'Q1'
        WHEN EXTRACT(MONTH FROM agreement_start_date::date) IN (7, 8, 9) THEN 'Q2'
        WHEN EXTRACT(MONTH FROM agreement_start_date::date) IN (10, 11, 12) THEN 'Q3'
        ELSE 'Q4'
      END as quarter,
      COUNT(*) as count,
      SUM(agreement_value) as total_value
    FROM grants_contributions
    ${whereClause}
    AND agreement_start_date IS NOT NULL
    GROUP BY fiscal_year, quarter
    ORDER BY fiscal_year DESC, quarter
  `;

  // Monthly analysis
  const monthlyQuery = `
    SELECT
      TO_CHAR(agreement_start_date::date, 'YYYY-MM') as month,
      COUNT(*) as count,
      SUM(agreement_value) as total_value,
      AVG(agreement_value) as avg_value
    FROM grants_contributions
    ${whereClause}
    AND agreement_start_date IS NOT NULL
    GROUP BY month
    ORDER BY month DESC
    LIMIT 36
  `;

  // Q4 spending analysis (fiscal year-end)
  const q4SpendingQuery = `
    WITH quarterly_totals AS (
      SELECT
        CASE
          WHEN EXTRACT(MONTH FROM agreement_start_date::date) >= 4
          THEN EXTRACT(YEAR FROM agreement_start_date::date)
          ELSE EXTRACT(YEAR FROM agreement_start_date::date) - 1
        END as fiscal_year,
        CASE
          WHEN EXTRACT(MONTH FROM agreement_start_date::date) IN (1, 2, 3) THEN 'Q4'
          ELSE 'Other'
        END as is_q4,
        SUM(agreement_value) as total_value
      FROM grants_contributions
      ${whereClause}
      AND agreement_start_date IS NOT NULL
      GROUP BY fiscal_year, is_q4
    )
    SELECT
      fiscal_year,
      SUM(CASE WHEN is_q4 = 'Q4' THEN total_value ELSE 0 END) as q4_value,
      SUM(total_value) as annual_value,
      CASE
        WHEN SUM(total_value) > 0
        THEN (SUM(CASE WHEN is_q4 = 'Q4' THEN total_value ELSE 0 END) / SUM(total_value)) * 100
        ELSE 0
      END as q4_ratio
    FROM quarterly_totals
    GROUP BY fiscal_year
    ORDER BY fiscal_year DESC
  `;

  // March spending analysis - by FISCAL YEAR
  const marchSpendingQuery = `
    SELECT
      CASE
        WHEN EXTRACT(MONTH FROM agreement_start_date::date) >= 4
        THEN EXTRACT(YEAR FROM agreement_start_date::date)
        ELSE EXTRACT(YEAR FROM agreement_start_date::date) - 1
      END as fiscal_year,
      COUNT(CASE WHEN EXTRACT(MONTH FROM agreement_start_date::date) = 3 THEN 1 END) as march_count,
      SUM(CASE WHEN EXTRACT(MONTH FROM agreement_start_date::date) = 3 THEN agreement_value ELSE 0 END) as march_value,
      SUM(CASE WHEN EXTRACT(MONTH FROM agreement_start_date::date) IN (1, 2, 3) THEN agreement_value ELSE 0 END) as q4_value,
      COUNT(*) as total_count,
      SUM(agreement_value) as total_value
    FROM grants_contributions
    ${whereClause}
    AND agreement_start_date IS NOT NULL
    GROUP BY fiscal_year
    ORDER BY fiscal_year DESC
    LIMIT 5
  `;

  // Project duration analysis
  const durationQuery = `
    SELECT
      COUNT(*) as total_with_dates,
      AVG(agreement_end_date::date - agreement_start_date::date) as avg_duration_days,
      PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY agreement_end_date::date - agreement_start_date::date) as median_duration_days,
      COUNT(CASE WHEN (agreement_end_date::date - agreement_start_date::date) < 90 THEN 1 END) as under_90_days,
      COUNT(CASE WHEN (agreement_end_date::date - agreement_start_date::date) < 180 THEN 1 END) as under_180_days,
      COUNT(CASE WHEN (agreement_end_date::date - agreement_start_date::date) >= 365 THEN 1 END) as over_1_year,
      COUNT(CASE WHEN (agreement_end_date::date - agreement_start_date::date) >= 730 THEN 1 END) as over_2_years
    FROM grants_contributions
    ${whereClause}
    AND agreement_start_date IS NOT NULL
    AND agreement_end_date IS NOT NULL
  `;

  // Amendment analysis
  const amendmentQuery = `
    SELECT
      COUNT(*) as total,
      COUNT(CASE WHEN amendment_number IS NOT NULL AND amendment_number != '' AND amendment_number != '0' THEN 1 END) as with_amendments,
      COUNT(DISTINCT CASE WHEN amendment_number IS NOT NULL AND amendment_number != '' AND amendment_number != '0' THEN recipient_legal_name END) as recipients_with_amendments
    FROM grants_contributions
    ${whereClause}
  `;

  const [fiscalYearResult, quarterResult, monthlyResult, q4SpendingResult, marchSpendingResult, durationResult, amendmentResult] = await Promise.all([
    pool.query(fiscalYearQuery, params),
    pool.query(quarterQuery, params),
    pool.query(monthlyQuery, params),
    pool.query(q4SpendingQuery, params),
    pool.query(marchSpendingQuery, params),
    pool.query(durationQuery, params),
    pool.query(amendmentQuery, params)
  ]);

  const duration = durationResult.rows[0];
  const amendment = amendmentResult.rows[0];

  return {
    by_fiscal_year: fiscalYearResult.rows.map(row => ({
      fiscal_year: row.fiscal_year,
      count: parseInt(row.count),
      total_value: parseFloat(row.total_value),
      avg_value: parseFloat(row.avg_value)
    })),
    by_quarter: quarterResult.rows.map(row => ({
      fiscal_year: row.fiscal_year,
      quarter: row.quarter,
      count: parseInt(row.count),
      total_value: parseFloat(row.total_value)
    })),
    by_month: monthlyResult.rows.map(row => ({
      month: row.month,
      count: parseInt(row.count),
      total_value: parseFloat(row.total_value),
      avg_value: parseFloat(row.avg_value)
    })),
    q4_analysis: q4SpendingResult.rows.map(row => ({
      fiscal_year: row.fiscal_year,
      q4_value: parseFloat(row.q4_value),
      annual_value: parseFloat(row.annual_value),
      q4_ratio: parseFloat(row.q4_ratio)
    })),
    march_analysis: marchSpendingResult.rows.map(row => ({
      fiscal_year: row.fiscal_year,
      march_count: parseInt(row.march_count),
      march_value: parseFloat(row.march_value),
      q4_value: parseFloat(row.q4_value),
      march_of_q4_ratio: row.q4_value > 0 ? (parseFloat(row.march_value) / parseFloat(row.q4_value)) * 100 : 0
    })),
    duration_analysis: {
      total_with_dates: parseInt(duration.total_with_dates),
      avg_duration_days: parseFloat(duration.avg_duration_days) || 0,
      median_duration_days: parseFloat(duration.median_duration_days) || 0,
      under_90_days: parseInt(duration.under_90_days),
      under_180_days: parseInt(duration.under_180_days),
      over_1_year: parseInt(duration.over_1_year),
      over_2_years: parseInt(duration.over_2_years),
      short_project_rate: duration.total_with_dates > 0 ? (parseInt(duration.under_180_days) / parseInt(duration.total_with_dates)) * 100 : 0
    },
    amendment_analysis: {
      total_agreements: parseInt(amendment.total),
      with_amendments: parseInt(amendment.with_amendments),
      recipients_with_amendments: parseInt(amendment.recipients_with_amendments),
      amendment_rate: amendment.total > 0 ? (parseInt(amendment.with_amendments) / parseInt(amendment.total)) * 100 : 0
    }
  };
};

// ==================== 4. GEOGRAPHIC ANALYSIS ====================

/**
 * Get comprehensive geographic analysis
 */
exports.getGeographicAnalysis = async (filters = {}) => {
  const { whereClause, params } = buildWhereClause(filters);

  // City-level distribution
  const cityQuery = `
    SELECT
      recipient_city,
      COUNT(*) as count,
      SUM(agreement_value) as total_value,
      AVG(agreement_value) as avg_value,
      COUNT(DISTINCT recipient_legal_name) as unique_recipients
    FROM grants_contributions
    ${whereClause}
    AND recipient_city IS NOT NULL
    AND recipient_city != ''
    GROUP BY recipient_city
    ORDER BY total_value DESC
    LIMIT 50
  `;

  // Federal riding distribution
  const ridingQuery = `
    SELECT
      federal_riding_name_en,
      federal_riding_number,
      COUNT(*) as count,
      SUM(agreement_value) as total_value,
      AVG(agreement_value) as avg_value,
      COUNT(DISTINCT recipient_legal_name) as unique_recipients
    FROM grants_contributions
    ${whereClause}
    AND federal_riding_name_en IS NOT NULL
    AND federal_riding_name_en != ''
    GROUP BY federal_riding_name_en, federal_riding_number
    ORDER BY total_value DESC
  `;

  // Urban/Rural classification (based on major Alberta cities)
  const urbanRuralQuery = `
    SELECT
      CASE
        WHEN recipient_city ILIKE ANY(ARRAY['Calgary', 'Edmonton']) THEN 'Metro'
        WHEN recipient_city ILIKE ANY(ARRAY['Red Deer', 'Lethbridge', 'Medicine Hat', 'Grande Prairie', 'Fort McMurray', 'Airdrie', 'St. Albert']) THEN 'Urban'
        WHEN recipient_city IS NOT NULL AND recipient_city != '' THEN 'Rural'
        ELSE 'Unknown'
      END as classification,
      COUNT(*) as count,
      SUM(agreement_value) as total_value,
      AVG(agreement_value) as avg_value,
      COUNT(DISTINCT recipient_legal_name) as unique_recipients
    FROM grants_contributions
    ${whereClause}
    GROUP BY classification
    ORDER BY total_value DESC
  `;

  // Postal code prefix analysis (first 3 characters)
  const postalQuery = `
    SELECT
      SUBSTRING(recipient_postal_code, 1, 3) as postal_prefix,
      COUNT(*) as count,
      SUM(agreement_value) as total_value,
      COUNT(DISTINCT recipient_legal_name) as unique_recipients
    FROM grants_contributions
    ${whereClause}
    AND recipient_postal_code IS NOT NULL
    AND recipient_postal_code != ''
    GROUP BY postal_prefix
    ORDER BY total_value DESC
    LIMIT 30
  `;

  const [cityResult, ridingResult, urbanRuralResult, postalResult] = await Promise.all([
    pool.query(cityQuery, params),
    pool.query(ridingQuery, params),
    pool.query(urbanRuralQuery, params),
    pool.query(postalQuery, params)
  ]);

  // Calculate urban/rural ratio
  const metroData = urbanRuralResult.rows.find(r => r.classification === 'Metro');
  const ruralData = urbanRuralResult.rows.find(r => r.classification === 'Rural');
  const urbanRuralRatio = (metroData && ruralData && ruralData.total_value > 0)
    ? parseFloat(metroData.total_value) / parseFloat(ruralData.total_value)
    : 0;

  return {
    by_city: cityResult.rows.map(row => ({
      recipient_city: row.recipient_city,
      count: parseInt(row.count),
      total_value: parseFloat(row.total_value),
      avg_value: parseFloat(row.avg_value),
      unique_recipients: parseInt(row.unique_recipients)
    })),
    by_riding: ridingResult.rows.map(row => ({
      federal_riding_name_en: row.federal_riding_name_en,
      federal_riding_number: row.federal_riding_number,
      count: parseInt(row.count),
      total_value: parseFloat(row.total_value),
      avg_value: parseFloat(row.avg_value),
      unique_recipients: parseInt(row.unique_recipients)
    })),
    urban_rural: urbanRuralResult.rows.map(row => ({
      classification: row.classification,
      count: parseInt(row.count),
      total_value: parseFloat(row.total_value),
      avg_value: parseFloat(row.avg_value),
      unique_recipients: parseInt(row.unique_recipients)
    })),
    by_postal_prefix: postalResult.rows.map(row => ({
      postal_prefix: row.postal_prefix,
      count: parseInt(row.count),
      total_value: parseFloat(row.total_value),
      unique_recipients: parseInt(row.unique_recipients)
    })),
    metrics: {
      urban_rural_ratio: urbanRuralRatio.toFixed(2),
      metro_share: metroData ? ((parseFloat(metroData.total_value) / urbanRuralResult.rows.reduce((sum, r) => sum + parseFloat(r.total_value), 0)) * 100).toFixed(2) : 0
    }
  };
};

// ==================== 5. RECIPIENT ANALYSIS ====================

/**
 * Get comprehensive recipient analysis
 */
exports.getRecipientAnalysis = async (filters = {}) => {
  const { whereClause, params } = buildWhereClause(filters);

  // Recipient concentration
  const recipientStatsQuery = `
    SELECT
      COUNT(DISTINCT recipient_legal_name) as unique_recipients,
      COUNT(*) as total_agreements,
      AVG(agreement_value) as avg_agreement_value
    FROM grants_contributions
    ${whereClause}
  `;

  // Repeat recipient analysis
  const repeatRecipientsQuery = `
    WITH recipient_counts AS (
      SELECT
        recipient_legal_name,
        COUNT(*) as agreement_count,
        SUM(agreement_value) as total_value,
        COUNT(DISTINCT prog_name_en) as program_count,
        COUNT(DISTINCT owner_org_title) as department_count,
        MIN(agreement_start_date) as first_agreement,
        MAX(agreement_start_date) as latest_agreement
      FROM grants_contributions
      ${whereClause}
      GROUP BY recipient_legal_name
    )
    SELECT
      COUNT(*) as total_recipients,
      COUNT(CASE WHEN agreement_count = 1 THEN 1 END) as one_time_recipients,
      COUNT(CASE WHEN agreement_count BETWEEN 2 AND 5 THEN 1 END) as occasional_recipients,
      COUNT(CASE WHEN agreement_count BETWEEN 6 AND 10 THEN 1 END) as frequent_recipients,
      COUNT(CASE WHEN agreement_count > 10 THEN 1 END) as very_frequent_recipients,
      AVG(agreement_count) as avg_agreements_per_recipient,
      AVG(program_count) as avg_programs_per_recipient,
      COUNT(CASE WHEN program_count >= 3 THEN 1 END) as multi_program_recipients,
      COUNT(CASE WHEN department_count >= 3 THEN 1 END) as multi_dept_recipients
    FROM recipient_counts
  `;

  // Top recipients
  const topRecipientsQuery = `
    SELECT
      recipient_legal_name,
      recipient_type,
      recipient_city,
      recipient_business_number,
      COUNT(*) as agreement_count,
      SUM(agreement_value) as total_value,
      AVG(agreement_value) as avg_value,
      COUNT(DISTINCT prog_name_en) as program_count,
      COUNT(DISTINCT owner_org_title) as department_count,
      MIN(agreement_start_date) as first_agreement,
      MAX(agreement_start_date) as latest_agreement,
      COUNT(CASE WHEN amendment_number IS NOT NULL AND amendment_number != '' AND amendment_number != '0' THEN 1 END) as amendments
    FROM grants_contributions
    ${whereClause}
    GROUP BY recipient_legal_name, recipient_type, recipient_city, recipient_business_number
    ORDER BY total_value DESC
    LIMIT 50
  `;

  // Recipient type distribution
  const typeDistQuery = `
    SELECT
      COALESCE(recipient_type, 'Not Specified') as recipient_type,
      COUNT(*) as count,
      SUM(agreement_value) as total_value,
      AVG(agreement_value) as avg_value,
      COUNT(DISTINCT recipient_legal_name) as unique_recipients
    FROM grants_contributions
    ${whereClause}
    GROUP BY recipient_type
    ORDER BY total_value DESC
  `;

  // New vs returning recipients by year
  const newVsReturningQuery = `
    WITH first_agreement AS (
      SELECT
        recipient_legal_name,
        MIN(EXTRACT(YEAR FROM agreement_start_date::date)) as first_year
      FROM grants_contributions
      ${whereClause}
      AND agreement_start_date IS NOT NULL
      GROUP BY recipient_legal_name
    ),
    yearly_recipients AS (
      SELECT
        EXTRACT(YEAR FROM g.agreement_start_date::date) as year,
        g.recipient_legal_name,
        f.first_year
      FROM grants_contributions g
      JOIN first_agreement f ON g.recipient_legal_name = f.recipient_legal_name
      ${whereClause}
      AND g.agreement_start_date IS NOT NULL
      GROUP BY year, g.recipient_legal_name, f.first_year
    )
    SELECT
      year,
      COUNT(*) as total_recipients,
      COUNT(CASE WHEN year = first_year THEN 1 END) as new_recipients,
      COUNT(CASE WHEN year > first_year THEN 1 END) as returning_recipients
    FROM yearly_recipients
    GROUP BY year
    ORDER BY year DESC
    LIMIT 10
  `;

  const [statsResult, repeatResult, topRecipientsResult, typeDistResult, newVsReturningResult] = await Promise.all([
    pool.query(recipientStatsQuery, params),
    pool.query(repeatRecipientsQuery, params),
    pool.query(topRecipientsQuery, params),
    pool.query(typeDistQuery, params),
    pool.query(newVsReturningQuery, params)
  ]);

  const stats = statsResult.rows[0];
  const repeat = repeatResult.rows[0];

  return {
    overview: {
      unique_recipients: parseInt(stats.unique_recipients),
      total_agreements: parseInt(stats.total_agreements),
      avg_agreement_value: parseFloat(stats.avg_agreement_value) || 0,
      avg_agreements_per_recipient: parseFloat(repeat.avg_agreements_per_recipient) || 0,
      repeat_recipient_rate: repeat.total_recipients > 0
        ? ((parseInt(repeat.total_recipients) - parseInt(repeat.one_time_recipients)) / parseInt(repeat.total_recipients)) * 100
        : 0
    },
    repeat_analysis: {
      total_recipients: parseInt(repeat.total_recipients),
      one_time: parseInt(repeat.one_time_recipients),
      occasional: parseInt(repeat.occasional_recipients),
      frequent: parseInt(repeat.frequent_recipients),
      very_frequent: parseInt(repeat.very_frequent_recipients),
      avg_programs_per_recipient: parseFloat(repeat.avg_programs_per_recipient) || 0,
      multi_program_recipients: parseInt(repeat.multi_program_recipients),
      multi_dept_recipients: parseInt(repeat.multi_dept_recipients)
    },
    top_recipients: topRecipientsResult.rows.map(row => ({
      recipient_legal_name: row.recipient_legal_name,
      recipient_type: row.recipient_type,
      recipient_city: row.recipient_city,
      recipient_business_number: row.recipient_business_number,
      agreement_count: parseInt(row.agreement_count),
      total_value: parseFloat(row.total_value),
      avg_value: parseFloat(row.avg_value),
      program_count: parseInt(row.program_count),
      department_count: parseInt(row.department_count),
      first_agreement: row.first_agreement,
      latest_agreement: row.latest_agreement,
      amendments: parseInt(row.amendments),
      amendment_rate: row.agreement_count > 0 ? (parseInt(row.amendments) / parseInt(row.agreement_count)) * 100 : 0
    })),
    by_type: typeDistResult.rows.map(row => ({
      recipient_type: row.recipient_type,
      count: parseInt(row.count),
      total_value: parseFloat(row.total_value),
      avg_value: parseFloat(row.avg_value),
      unique_recipients: parseInt(row.unique_recipients)
    })),
    new_vs_returning: newVsReturningResult.rows.map(row => ({
      year: parseInt(row.year),
      total_recipients: parseInt(row.total_recipients),
      new_recipients: parseInt(row.new_recipients),
      returning_recipients: parseInt(row.returning_recipients),
      new_recipient_rate: row.total_recipients > 0 ? (parseInt(row.new_recipients) / parseInt(row.total_recipients)) * 100 : 0
    }))
  };
};

// ==================== 6. PROGRAM ANALYSIS ====================

/**
 * Get comprehensive program analysis
 */
exports.getProgramAnalysis = async (filters = {}) => {
  const { whereClause, params } = buildWhereClause(filters);

  // Program statistics
  const programStatsQuery = `
    SELECT
      prog_name_en,
      owner_org_title,
      COUNT(*) as agreement_count,
      SUM(agreement_value) as total_value,
      AVG(agreement_value) as avg_value,
      MIN(agreement_value) as min_value,
      MAX(agreement_value) as max_value,
      COUNT(DISTINCT recipient_legal_name) as unique_recipients,
      COUNT(DISTINCT recipient_city) as cities_served,
      MIN(agreement_start_date) as first_agreement,
      MAX(agreement_start_date) as latest_agreement,
      COUNT(CASE WHEN amendment_number IS NOT NULL AND amendment_number != '' AND amendment_number != '0' THEN 1 END) as amendments,
      COUNT(CASE WHEN expected_results_en IS NOT NULL AND expected_results_en != '' THEN 1 END) as with_expected_results,
      COUNT(CASE WHEN description_en IS NOT NULL AND description_en != '' THEN 1 END) as with_description
    FROM grants_contributions
    ${whereClause}
    AND prog_name_en IS NOT NULL
    AND prog_name_en != ''
    GROUP BY prog_name_en, owner_org_title
    ORDER BY total_value DESC
    LIMIT 100
  `;

  // Department program count
  const deptProgramCountQuery = `
    SELECT
      owner_org_title,
      COUNT(DISTINCT prog_name_en) as program_count,
      COUNT(*) as total_agreements,
      SUM(agreement_value) as total_value
    FROM grants_contributions
    ${whereClause}
    AND owner_org_title IS NOT NULL
    AND prog_name_en IS NOT NULL
    GROUP BY owner_org_title
    ORDER BY program_count DESC
  `;

  // Program continuity (years active)
  const continuitQuery = `
    WITH program_years AS (
      SELECT
        prog_name_en,
        EXTRACT(YEAR FROM agreement_start_date::date) as year
      FROM grants_contributions
      ${whereClause}
      AND prog_name_en IS NOT NULL
      AND agreement_start_date IS NOT NULL
      GROUP BY prog_name_en, year
    )
    SELECT
      prog_name_en,
      COUNT(DISTINCT year) as years_active,
      MIN(year) as first_year,
      MAX(year) as latest_year
    FROM program_years
    GROUP BY prog_name_en
    ORDER BY years_active DESC
    LIMIT 50
  `;

  // Description quality analysis
  const qualityQuery = `
    SELECT
      COUNT(*) as total,
      COUNT(CASE WHEN description_en IS NOT NULL AND LENGTH(description_en) > 100 THEN 1 END) as detailed_description,
      COUNT(CASE WHEN expected_results_en IS NOT NULL AND LENGTH(expected_results_en) > 50 THEN 1 END) as has_expected_results,
      COUNT(CASE WHEN naics_identifier IS NOT NULL AND naics_identifier != '' THEN 1 END) as has_naics,
      COUNT(CASE WHEN recipient_type IS NOT NULL AND recipient_type != '' THEN 1 END) as has_recipient_type,
      COUNT(CASE WHEN recipient_business_number IS NOT NULL AND recipient_business_number != '' THEN 1 END) as has_business_number
    FROM grants_contributions
    ${whereClause}
  `;

  const [programStatsResult, deptProgramCountResult, continuityResult, qualityResult] = await Promise.all([
    pool.query(programStatsQuery, params),
    pool.query(deptProgramCountQuery, params),
    pool.query(continuitQuery, params),
    pool.query(qualityQuery, params)
  ]);

  const quality = qualityResult.rows[0];

  return {
    programs: programStatsResult.rows.map(row => ({
      prog_name_en: row.prog_name_en,
      owner_org_title: row.owner_org_title,
      agreement_count: parseInt(row.agreement_count),
      total_value: parseFloat(row.total_value),
      avg_value: parseFloat(row.avg_value),
      min_value: parseFloat(row.min_value),
      max_value: parseFloat(row.max_value),
      unique_recipients: parseInt(row.unique_recipients),
      cities_served: parseInt(row.cities_served),
      first_agreement: row.first_agreement,
      latest_agreement: row.latest_agreement,
      amendments: parseInt(row.amendments),
      amendment_rate: row.agreement_count > 0 ? (parseInt(row.amendments) / parseInt(row.agreement_count)) * 100 : 0,
      description_rate: row.agreement_count > 0 ? (parseInt(row.with_description) / parseInt(row.agreement_count)) * 100 : 0,
      expected_results_rate: row.agreement_count > 0 ? (parseInt(row.with_expected_results) / parseInt(row.agreement_count)) * 100 : 0
    })),
    by_department: deptProgramCountResult.rows.map(row => ({
      owner_org_title: row.owner_org_title,
      program_count: parseInt(row.program_count),
      total_agreements: parseInt(row.total_agreements),
      total_value: parseFloat(row.total_value),
      fragmentation_indicator: parseInt(row.program_count) > 50 ? 'High' : parseInt(row.program_count) > 20 ? 'Moderate' : 'Low'
    })),
    continuity: continuityResult.rows.map(row => ({
      prog_name_en: row.prog_name_en,
      years_active: parseInt(row.years_active),
      first_year: parseInt(row.first_year),
      latest_year: parseInt(row.latest_year),
      continuity_indicator: parseInt(row.years_active) > 10 ? 'Long-standing' : parseInt(row.years_active) > 5 ? 'Established' : 'Recent'
    })),
    data_quality: {
      total: parseInt(quality.total),
      detailed_description_rate: (parseInt(quality.detailed_description) / parseInt(quality.total)) * 100,
      expected_results_rate: (parseInt(quality.has_expected_results) / parseInt(quality.total)) * 100,
      naics_completion: (parseInt(quality.has_naics) / parseInt(quality.total)) * 100,
      recipient_type_completion: (parseInt(quality.has_recipient_type) / parseInt(quality.total)) * 100,
      business_number_completion: (parseInt(quality.has_business_number) / parseInt(quality.total)) * 100
    }
  };
};

// ==================== 7. RISK ANALYSIS ====================

/**
 * Calculate risk score for agreements
 */
exports.getRiskAnalysis = async (filters = {}) => {
  const { whereClause, params } = buildWhereClause(filters);

  // High-value agreements
  const highValueQuery = `
    SELECT
      _id,
      ref_number,
      recipient_legal_name,
      agreement_value,
      prog_name_en,
      agreement_start_date,
      agreement_end_date,
      CASE WHEN amendment_number IS NOT NULL AND amendment_number != '' AND amendment_number != '0' THEN 'Yes' ELSE 'No' END as has_amendment,
      CASE WHEN expected_results_en IS NULL OR expected_results_en = '' THEN 'No' ELSE 'Yes' END as has_expected_results,
      CASE WHEN recipient_business_number IS NULL OR recipient_business_number = '' THEN 'No' ELSE 'Yes' END as has_business_number
    FROM grants_contributions
    ${whereClause}
    AND agreement_value >= 1000000
    ORDER BY agreement_value DESC
    LIMIT 100
  `;

  // Fiscal year-end agreements (March)
  const fyeAgreementsQuery = `
    SELECT
      COUNT(*) as march_agreements,
      SUM(agreement_value) as march_value,
      COUNT(CASE WHEN (agreement_end_date::date - agreement_start_date::date) < 30 THEN 1 END) as march_short_duration
    FROM grants_contributions
    ${whereClause}
    AND agreement_start_date IS NOT NULL
    AND EXTRACT(MONTH FROM agreement_start_date::date) = 3
  `;

  // Missing critical data
  const missingDataQuery = `
    SELECT
      COUNT(CASE WHEN recipient_business_number IS NULL OR recipient_business_number = '' THEN 1 END) as missing_business_number,
      COUNT(CASE WHEN recipient_type IS NULL OR recipient_type = '' THEN 1 END) as missing_recipient_type,
      COUNT(CASE WHEN expected_results_en IS NULL OR expected_results_en = '' THEN 1 END) as missing_expected_results,
      COUNT(CASE WHEN description_en IS NULL OR description_en = '' THEN 1 END) as missing_description,
      COUNT(CASE WHEN recipient_city IS NULL OR recipient_city = '' THEN 1 END) as missing_city,
      COUNT(CASE WHEN recipient_postal_code IS NULL OR recipient_postal_code = '' THEN 1 END) as missing_postal,
      COUNT(*) as total
    FROM grants_contributions
    ${whereClause}
    AND agreement_value >= 100000
  `;

  // Multi-amendment agreements
  const amendmentRiskQuery = `
    WITH amendment_counts AS (
      SELECT
        recipient_legal_name,
        prog_name_en,
        COUNT(CASE WHEN amendment_number IS NOT NULL AND amendment_number != '' AND amendment_number != '0' THEN 1 END) as amendment_count,
        COUNT(*) as total_agreements
      FROM grants_contributions
      ${whereClause}
      GROUP BY recipient_legal_name, prog_name_en
      HAVING COUNT(CASE WHEN amendment_number IS NOT NULL AND amendment_number != '' AND amendment_number != '0' THEN 1 END) > 0
    )
    SELECT
      recipient_legal_name,
      prog_name_en,
      amendment_count,
      total_agreements,
      (amendment_count::float / total_agreements * 100) as amendment_rate
    FROM amendment_counts
    WHERE (amendment_count::float / total_agreements) > 40
    ORDER BY amendment_rate DESC
    LIMIT 50
  `;

  // Unusual durations
  const durationRiskQuery = `
    SELECT
      COUNT(CASE WHEN (agreement_end_date::date - agreement_start_date::date) < 30
                AND agreement_value >= 100000 THEN 1 END) as high_value_short_duration,
      COUNT(CASE WHEN (agreement_end_date::date - agreement_start_date::date) > 1825 THEN 1 END) as very_long_duration,
      COUNT(CASE WHEN (agreement_end_date::date - agreement_start_date::date) < 0 THEN 1 END) as negative_duration
    FROM grants_contributions
    ${whereClause}
    AND agreement_start_date IS NOT NULL
    AND agreement_end_date IS NOT NULL
  `;

  const [highValueResult, fyeResult, missingDataResult, amendmentRiskResult, durationRiskResult] = await Promise.all([
    pool.query(highValueQuery, params),
    pool.query(fyeAgreementsQuery, params),
    pool.query(missingDataQuery, params),
    pool.query(amendmentRiskQuery, params),
    pool.query(durationRiskQuery, params)
  ]);

  const fye = fyeResult.rows[0];
  const missing = missingDataResult.rows[0];
  const duration = durationRiskResult.rows[0];

  return {
    high_value_agreements: highValueResult.rows.map(row => ({
      _id: row._id,
      ref_number: row.ref_number,
      recipient_legal_name: row.recipient_legal_name,
      agreement_value: parseFloat(row.agreement_value),
      prog_name_en: row.prog_name_en,
      agreement_start_date: row.agreement_start_date,
      agreement_end_date: row.agreement_end_date,
      has_amendment: row.has_amendment,
      has_expected_results: row.has_expected_results,
      has_business_number: row.has_business_number
    })),
    fiscal_year_end_risk: {
      march_agreements: parseInt(fye.march_agreements),
      march_value: parseFloat(fye.march_value) || 0,
      march_short_duration: parseInt(fye.march_short_duration)
    },
    data_completeness_risk: {
      total_high_value: parseInt(missing.total),
      missing_business_number: parseInt(missing.missing_business_number),
      missing_recipient_type: parseInt(missing.missing_recipient_type),
      missing_expected_results: parseInt(missing.missing_expected_results),
      missing_description: parseInt(missing.missing_description),
      missing_city: parseInt(missing.missing_city),
      missing_postal: parseInt(missing.missing_postal),
      completeness_score: missing.total > 0
        ? 100 - ((parseInt(missing.missing_business_number) + parseInt(missing.missing_expected_results)) / (parseInt(missing.total) * 2) * 100)
        : 100
    },
    high_amendment_recipients: amendmentRiskResult.rows.map(row => ({
      recipient_legal_name: row.recipient_legal_name,
      prog_name_en: row.prog_name_en,
      amendment_count: parseInt(row.amendment_count),
      total_agreements: parseInt(row.total_agreements),
      amendment_rate: parseFloat(row.amendment_rate)
    })),
    duration_risks: {
      high_value_short_duration: parseInt(duration.high_value_short_duration),
      very_long_duration: parseInt(duration.very_long_duration),
      negative_duration: parseInt(duration.negative_duration)
    }
  };
};

// ==================== 8. EQUITY & ACCESS ANALYSIS ====================

/**
 * Get equity and access analysis
 */
exports.getEquityAnalysis = async (filters = {}) => {
  const { whereClause, params } = buildWhereClause(filters);

  // Small vs large organization proxy (by average agreement size)
  const orgSizeQuery = `
    WITH recipient_avg AS (
      SELECT
        recipient_legal_name,
        AVG(agreement_value) as avg_value,
        COUNT(*) as agreement_count,
        SUM(agreement_value) as total_value
      FROM grants_contributions
      ${whereClause}
      GROUP BY recipient_legal_name
    )
    SELECT
      COUNT(CASE WHEN avg_value < 50000 THEN 1 END) as small_org_count,
      SUM(CASE WHEN avg_value < 50000 THEN total_value ELSE 0 END) as small_org_value,
      COUNT(CASE WHEN avg_value >= 50000 AND avg_value < 250000 THEN 1 END) as medium_org_count,
      SUM(CASE WHEN avg_value >= 50000 AND avg_value < 250000 THEN total_value ELSE 0 END) as medium_org_value,
      COUNT(CASE WHEN avg_value >= 250000 THEN 1 END) as large_org_count,
      SUM(CASE WHEN avg_value >= 250000 THEN total_value ELSE 0 END) as large_org_value,
      COUNT(*) as total_orgs,
      SUM(total_value) as total_value
    FROM recipient_avg
  `;

  // Geographic equity (urban vs rural)
  const geoEquityQuery = `
    WITH classified AS (
      SELECT
        CASE
          WHEN recipient_city ILIKE ANY(ARRAY['Calgary', 'Edmonton']) THEN 'Metro'
          WHEN recipient_city ILIKE ANY(ARRAY['Red Deer', 'Lethbridge', 'Medicine Hat', 'Grande Prairie', 'Fort McMurray']) THEN 'Urban'
          ELSE 'Rural/Small'
        END as classification,
        agreement_value
      FROM grants_contributions
      ${whereClause}
      AND recipient_city IS NOT NULL
    )
    SELECT
      classification,
      COUNT(*) as count,
      SUM(agreement_value) as total_value,
      AVG(agreement_value) as avg_value
    FROM classified
    GROUP BY classification
  `;

  // Recipient type equity
  const typeEquityQuery = `
    SELECT
      COALESCE(recipient_type, 'Not Specified') as recipient_type,
      COUNT(*) as count,
      SUM(agreement_value) as total_value,
      AVG(agreement_value) as avg_value,
      COUNT(DISTINCT recipient_legal_name) as unique_recipients
    FROM grants_contributions
    ${whereClause}
    GROUP BY recipient_type
    ORDER BY total_value DESC
  `;

  // First-time recipient access by region
  const firstTimeAccessQuery = `
    WITH first_agreements AS (
      SELECT
        recipient_legal_name,
        MIN(agreement_start_date) as first_date,
        FIRST_VALUE(recipient_city) OVER (PARTITION BY recipient_legal_name ORDER BY agreement_start_date) as city
      FROM grants_contributions
      ${whereClause}
      AND agreement_start_date IS NOT NULL
      GROUP BY recipient_legal_name, agreement_start_date, recipient_city
    ),
    classified_first AS (
      SELECT DISTINCT
        recipient_legal_name,
        CASE
          WHEN city ILIKE ANY(ARRAY['Calgary', 'Edmonton']) THEN 'Metro'
          WHEN city ILIKE ANY(ARRAY['Red Deer', 'Lethbridge', 'Medicine Hat', 'Grande Prairie']) THEN 'Urban'
          ELSE 'Rural/Small'
        END as classification
      FROM first_agreements
      WHERE city IS NOT NULL
    )
    SELECT
      classification,
      COUNT(*) as new_recipient_count
    FROM classified_first
    GROUP BY classification
  `;

  const [orgSizeResult, geoEquityResult, typeEquityResult, firstTimeAccessResult] = await Promise.all([
    pool.query(orgSizeQuery, params),
    pool.query(geoEquityQuery, params),
    pool.query(typeEquityQuery, params),
    pool.query(firstTimeAccessQuery, params)
  ]);

  const orgSize = orgSizeResult.rows[0];

  return {
    organization_size_equity: {
      small_org_count: parseInt(orgSize.small_org_count),
      small_org_value: parseFloat(orgSize.small_org_value) || 0,
      small_org_share: orgSize.total_value > 0 ? (parseFloat(orgSize.small_org_value) / parseFloat(orgSize.total_value)) * 100 : 0,
      medium_org_count: parseInt(orgSize.medium_org_count),
      medium_org_value: parseFloat(orgSize.medium_org_value) || 0,
      medium_org_share: orgSize.total_value > 0 ? (parseFloat(orgSize.medium_org_value) / parseFloat(orgSize.total_value)) * 100 : 0,
      large_org_count: parseInt(orgSize.large_org_count),
      large_org_value: parseFloat(orgSize.large_org_value) || 0,
      large_org_share: orgSize.total_value > 0 ? (parseFloat(orgSize.large_org_value) / parseFloat(orgSize.total_value)) * 100 : 0
    },
    geographic_equity: geoEquityResult.rows.map(row => ({
      classification: row.classification,
      count: parseInt(row.count),
      total_value: parseFloat(row.total_value),
      avg_value: parseFloat(row.avg_value)
    })),
    recipient_type_equity: typeEquityResult.rows.map(row => ({
      recipient_type: row.recipient_type,
      count: parseInt(row.count),
      total_value: parseFloat(row.total_value),
      avg_value: parseFloat(row.avg_value),
      unique_recipients: parseInt(row.unique_recipients)
    })),
    first_time_access_by_region: firstTimeAccessResult.rows.map(row => ({
      classification: row.classification,
      new_recipient_count: parseInt(row.new_recipient_count)
    }))
  };
};

// ==================== 9. OPERATIONAL EFFICIENCY ANALYSIS ====================

/**
 * Get operational efficiency analysis
 */
exports.getOperationalAnalysis = async (filters = {}) => {
  const { whereClause, params } = buildWhereClause(filters);

  // Transaction volume efficiency
  const efficiencyQuery = `
    SELECT
      prog_name_en,
      owner_org_title,
      COUNT(*) as agreement_count,
      SUM(agreement_value) as total_value,
      AVG(agreement_value) as avg_value,
      COUNT(CASE WHEN agreement_value < 10000 THEN 1 END) as micro_transactions,
      COUNT(CASE WHEN amendment_number IS NOT NULL AND amendment_number != '' AND amendment_number != '0' THEN 1 END) as amendments
    FROM grants_contributions
    ${whereClause}
    AND prog_name_en IS NOT NULL
    GROUP BY prog_name_en, owner_org_title
    HAVING COUNT(*) >= 10
    ORDER BY agreement_count DESC
    LIMIT 50
  `;

  // Multi-year vs annual
  const multiYearQuery = `
    SELECT
      COUNT(CASE WHEN (agreement_end_date::date - agreement_start_date::date) >= 365 THEN 1 END) as multi_year,
      COUNT(CASE WHEN (agreement_end_date::date - agreement_start_date::date) < 365 THEN 1 END) as annual_or_less,
      COUNT(*) as total_with_dates
    FROM grants_contributions
    ${whereClause}
    AND agreement_start_date IS NOT NULL
    AND agreement_end_date IS NOT NULL
  `;

  // Renewal patterns (same recipient, same program, sequential years)
  const renewalQuery = `
    WITH yearly_recipients AS (
      SELECT
        recipient_legal_name,
        prog_name_en,
        EXTRACT(YEAR FROM agreement_start_date::date) as year,
        COUNT(*) as agreements_in_year
      FROM grants_contributions
      ${whereClause}
      AND agreement_start_date IS NOT NULL
      GROUP BY recipient_legal_name, prog_name_en, year
    ),
    consecutive_years AS (
      SELECT
        recipient_legal_name,
        prog_name_en,
        COUNT(DISTINCT year) as years_funded,
        MAX(year) - MIN(year) + 1 as year_span
      FROM yearly_recipients
      GROUP BY recipient_legal_name, prog_name_en
      HAVING COUNT(DISTINCT year) >= 3
    )
    SELECT
      COUNT(*) as consistent_recipients,
      AVG(years_funded) as avg_years_funded
    FROM consecutive_years
    WHERE years_funded = year_span
  `;

  // Administrative burden proxy
  const burdenQuery = `
    SELECT
      recipient_legal_name,
      COUNT(*) as separate_agreements,
      SUM(agreement_value) as total_value,
      AVG(agreement_value) as avg_value,
      COUNT(DISTINCT prog_name_en) as programs,
      COUNT(DISTINCT EXTRACT(YEAR FROM agreement_start_date::date)) as years_active
    FROM grants_contributions
    ${whereClause}
    AND agreement_start_date IS NOT NULL
    GROUP BY recipient_legal_name
    HAVING COUNT(*) >= 5 AND AVG(agreement_value) < 50000
    ORDER BY separate_agreements DESC
    LIMIT 30
  `;

  const [efficiencyResult, multiYearResult, renewalResult, burdenResult] = await Promise.all([
    pool.query(efficiencyQuery, params),
    pool.query(multiYearQuery, params),
    pool.query(renewalQuery, params),
    pool.query(burdenQuery, params)
  ]);

  const multiYear = multiYearResult.rows[0];
  const renewal = renewalResult.rows[0];

  return {
    program_efficiency: efficiencyResult.rows.map(row => ({
      prog_name_en: row.prog_name_en,
      owner_org_title: row.owner_org_title,
      agreement_count: parseInt(row.agreement_count),
      total_value: parseFloat(row.total_value),
      avg_value: parseFloat(row.avg_value),
      micro_transactions: parseInt(row.micro_transactions),
      amendments: parseInt(row.amendments),
      efficiency_indicator: parseInt(row.agreement_count) > 100 && parseFloat(row.avg_value) < 25000
        ? 'Consolidation Opportunity'
        : 'Normal'
    })),
    multi_year_analysis: {
      multi_year_count: parseInt(multiYear.multi_year),
      annual_or_less_count: parseInt(multiYear.annual_or_less),
      total_with_dates: parseInt(multiYear.total_with_dates),
      multi_year_rate: multiYear.total_with_dates > 0
        ? (parseInt(multiYear.multi_year) / parseInt(multiYear.total_with_dates)) * 100
        : 0
    },
    renewal_patterns: {
      consistent_recipients: parseInt(renewal.consistent_recipients) || 0,
      avg_years_funded: parseFloat(renewal.avg_years_funded) || 0,
      multi_year_opportunity: parseInt(renewal.consistent_recipients) > 0 ? 'Yes' : 'Limited'
    },
    administrative_burden: burdenResult.rows.map(row => ({
      recipient_legal_name: row.recipient_legal_name,
      separate_agreements: parseInt(row.separate_agreements),
      total_value: parseFloat(row.total_value),
      avg_value: parseFloat(row.avg_value),
      programs: parseInt(row.programs),
      years_active: parseInt(row.years_active),
      consolidation_potential: 'High'
    }))
  };
};

// ==================== 10. DATA QUALITY ANALYSIS ====================

/**
 * Get data quality assessment
 */
exports.getDataQualityAnalysis = async (filters = {}) => {
  const { whereClause, params } = buildWhereClause(filters);

  // Overall completeness
  const completenessQuery = `
    SELECT
      COUNT(*) as total_records,
      COUNT(CASE WHEN recipient_legal_name IS NOT NULL AND recipient_legal_name != '' THEN 1 END) as has_legal_name,
      COUNT(CASE WHEN agreement_value IS NOT NULL THEN 1 END) as has_value,
      COUNT(CASE WHEN agreement_start_date IS NOT NULL THEN 1 END) as has_start_date,
      COUNT(CASE WHEN recipient_province IS NOT NULL AND recipient_province != '' THEN 1 END) as has_province,
      COUNT(CASE WHEN recipient_city IS NOT NULL AND recipient_city != '' THEN 1 END) as has_city,
      COUNT(CASE WHEN recipient_postal_code IS NOT NULL AND recipient_postal_code != '' THEN 1 END) as has_postal,
      COUNT(CASE WHEN recipient_type IS NOT NULL AND recipient_type != '' THEN 1 END) as has_type,
      COUNT(CASE WHEN recipient_business_number IS NOT NULL AND recipient_business_number != '' THEN 1 END) as has_business_number,
      COUNT(CASE WHEN naics_identifier IS NOT NULL AND naics_identifier != '' THEN 1 END) as has_naics,
      COUNT(CASE WHEN federal_riding_name_en IS NOT NULL AND federal_riding_name_en != '' THEN 1 END) as has_riding,
      COUNT(CASE WHEN expected_results_en IS NOT NULL AND expected_results_en != '' THEN 1 END) as has_expected_results,
      COUNT(CASE WHEN description_en IS NOT NULL AND description_en != '' THEN 1 END) as has_description,
      COUNT(CASE WHEN prog_name_en IS NOT NULL AND prog_name_en != '' THEN 1 END) as has_program,
      COUNT(CASE WHEN owner_org_title IS NOT NULL AND owner_org_title != '' THEN 1 END) as has_owner_org,
      COUNT(CASE WHEN agreement_end_date IS NOT NULL THEN 1 END) as has_end_date
    FROM grants_contributions
    ${whereClause}
  `;

  // Quality by department
  const deptQualityQuery = `
    SELECT
      owner_org_title,
      COUNT(*) as total,
      COUNT(CASE WHEN recipient_business_number IS NOT NULL AND recipient_business_number != '' THEN 1 END) as has_business_number,
      COUNT(CASE WHEN expected_results_en IS NOT NULL AND expected_results_en != '' THEN 1 END) as has_expected_results,
      COUNT(CASE WHEN naics_identifier IS NOT NULL AND naics_identifier != '' THEN 1 END) as has_naics,
      COUNT(CASE WHEN recipient_type IS NOT NULL AND recipient_type != '' THEN 1 END) as has_type
    FROM grants_contributions
    ${whereClause}
    AND owner_org_title IS NOT NULL
    GROUP BY owner_org_title
    ORDER BY total DESC
    LIMIT 20
  `;

  // Data consistency checks
  const consistencyQuery = `
    SELECT
      COUNT(CASE WHEN agreement_end_date < agreement_start_date THEN 1 END) as invalid_dates,
      COUNT(CASE WHEN agreement_value <= 0 THEN 1 END) as invalid_values,
      COUNT(CASE WHEN LENGTH(recipient_postal_code) < 6 THEN 1 END) as invalid_postal,
      COUNT(*) as total
    FROM grants_contributions
    ${whereClause}
    AND agreement_start_date IS NOT NULL
    AND agreement_end_date IS NOT NULL
  `;

  const [completenessResult, deptQualityResult, consistencyResult] = await Promise.all([
    pool.query(completenessQuery, params),
    pool.query(deptQualityQuery, params),
    pool.query(consistencyQuery, params)
  ]);

  const comp = completenessResult.rows[0];
  const cons = consistencyResult.rows[0];
  const total = parseInt(comp.total_records);

  // Calculate weighted completeness score
  const weights = {
    legal_name: 15, value: 15, start_date: 15, province: 10,
    city: 8, postal: 5, type: 8, business_number: 5,
    naics: 5, riding: 4, expected_results: 5, description: 5
  };

  const weightedScore = total > 0 ? (
    (parseInt(comp.has_legal_name) / total * weights.legal_name) +
    (parseInt(comp.has_value) / total * weights.value) +
    (parseInt(comp.has_start_date) / total * weights.start_date) +
    (parseInt(comp.has_province) / total * weights.province) +
    (parseInt(comp.has_city) / total * weights.city) +
    (parseInt(comp.has_postal) / total * weights.postal) +
    (parseInt(comp.has_type) / total * weights.type) +
    (parseInt(comp.has_business_number) / total * weights.business_number) +
    (parseInt(comp.has_naics) / total * weights.naics) +
    (parseInt(comp.has_riding) / total * weights.riding) +
    (parseInt(comp.has_expected_results) / total * weights.expected_results) +
    (parseInt(comp.has_description) / total * weights.description)
  ) : 0;

  return {
    overview: {
      total_records: total,
      weighted_quality_score: weightedScore.toFixed(2),
      quality_grade: weightedScore >= 90 ? 'A' : weightedScore >= 80 ? 'B' : weightedScore >= 70 ? 'C' : weightedScore >= 60 ? 'D' : 'F'
    },
    field_completeness: {
      recipient_legal_name: {
        count: parseInt(comp.has_legal_name),
        rate: (parseInt(comp.has_legal_name) / total * 100).toFixed(2),
        criticality: 'Essential'
      },
      agreement_value: {
        count: parseInt(comp.has_value),
        rate: (parseInt(comp.has_value) / total * 100).toFixed(2),
        criticality: 'Essential'
      },
      agreement_start_date: {
        count: parseInt(comp.has_start_date),
        rate: (parseInt(comp.has_start_date) / total * 100).toFixed(2),
        criticality: 'Essential'
      },
      agreement_end_date: {
        count: parseInt(comp.has_end_date),
        rate: (parseInt(comp.has_end_date) / total * 100).toFixed(2),
        criticality: 'Essential'
      },
      recipient_province: {
        count: parseInt(comp.has_province),
        rate: (parseInt(comp.has_province) / total * 100).toFixed(2),
        criticality: 'Essential'
      },
      recipient_city: {
        count: parseInt(comp.has_city),
        rate: (parseInt(comp.has_city) / total * 100).toFixed(2),
        criticality: 'High'
      },
      recipient_postal_code: {
        count: parseInt(comp.has_postal),
        rate: (parseInt(comp.has_postal) / total * 100).toFixed(2),
        criticality: 'High'
      },
      recipient_type: {
        count: parseInt(comp.has_type),
        rate: (parseInt(comp.has_type) / total * 100).toFixed(2),
        criticality: 'High'
      },
      recipient_business_number: {
        count: parseInt(comp.has_business_number),
        rate: (parseInt(comp.has_business_number) / total * 100).toFixed(2),
        criticality: 'Medium'
      },
      naics_identifier: {
        count: parseInt(comp.has_naics),
        rate: (parseInt(comp.has_naics) / total * 100).toFixed(2),
        criticality: 'Medium'
      },
      federal_riding: {
        count: parseInt(comp.has_riding),
        rate: (parseInt(comp.has_riding) / total * 100).toFixed(2),
        criticality: 'Low'
      },
      expected_results: {
        count: parseInt(comp.has_expected_results),
        rate: (parseInt(comp.has_expected_results) / total * 100).toFixed(2),
        criticality: 'Medium'
      },
      description: {
        count: parseInt(comp.has_description),
        rate: (parseInt(comp.has_description) / total * 100).toFixed(2),
        criticality: 'Medium'
      }
    },
    by_department: deptQualityResult.rows.map(row => ({
      owner_org_title: row.owner_org_title,
      total: parseInt(row.total),
      business_number_rate: (parseInt(row.has_business_number) / parseInt(row.total) * 100).toFixed(2),
      expected_results_rate: (parseInt(row.has_expected_results) / parseInt(row.total) * 100).toFixed(2),
      naics_rate: (parseInt(row.has_naics) / parseInt(row.total) * 100).toFixed(2),
      type_rate: (parseInt(row.has_type) / parseInt(row.total) * 100).toFixed(2)
    })),
    consistency_checks: {
      total_checked: parseInt(cons.total),
      invalid_dates: parseInt(cons.invalid_dates),
      invalid_values: parseInt(cons.invalid_values),
      invalid_postal: parseInt(cons.invalid_postal),
      consistency_rate: cons.total > 0
        ? ((parseInt(cons.total) - parseInt(cons.invalid_dates) - parseInt(cons.invalid_values)) / parseInt(cons.total) * 100).toFixed(2)
        : 100
    }
  };
};

// ==================== 11. ANOMALY DETECTION ====================

/**
 * Detect anomalies and generate alerts
 */
exports.getAnomalyDetection = async (filters = {}) => {
  const { whereClause, params } = buildWhereClause(filters);

  // Helper to add additional condition to WHERE clause
  const addCondition = (condition) => {
    if (whereClause) {
      return `${whereClause} AND ${condition}`;
    }
    return `WHERE ${condition}`;
  };

  const alerts = [];

  // 1. Statistical outliers (values > 3 std dev from mean)
  const outlierQuery = `
    WITH stats AS (
      SELECT
        prog_name_en,
        AVG(agreement_value) as mean_value,
        STDDEV(agreement_value) as stddev_value
      FROM grants_contributions
      ${addCondition('prog_name_en IS NOT NULL')}
      GROUP BY prog_name_en
      HAVING COUNT(*) >= 10 AND STDDEV(agreement_value) > 0
    )
    SELECT
      g._id,
      g.ref_number,
      g.recipient_legal_name,
      g.prog_name_en,
      g.agreement_value,
      s.mean_value,
      s.stddev_value,
      ABS(g.agreement_value - s.mean_value) / NULLIF(s.stddev_value, 0) as z_score
    FROM grants_contributions g
    JOIN stats s ON g.prog_name_en = s.prog_name_en
    ${addCondition('s.stddev_value > 0 AND ABS(g.agreement_value - s.mean_value) / NULLIF(s.stddev_value, 0) > 3')}
    ORDER BY z_score DESC
    LIMIT 50
  `;

  // 2. Threshold gaming (values just below reporting thresholds)
  const thresholdQuery = `
    SELECT
      _id,
      ref_number,
      recipient_legal_name,
      prog_name_en,
      agreement_value,
      CASE
        WHEN agreement_value BETWEEN 24900 AND 24999 THEN '25K threshold'
        WHEN agreement_value BETWEEN 99900 AND 99999 THEN '100K threshold'
        WHEN agreement_value BETWEEN 499900 AND 499999 THEN '500K threshold'
      END as threshold_indicator
    FROM grants_contributions
    ${addCondition(`(
      (agreement_value BETWEEN 24900 AND 24999) OR
      (agreement_value BETWEEN 99900 AND 99999) OR
      (agreement_value BETWEEN 499900 AND 499999)
    )`)}
    ORDER BY agreement_value DESC
    LIMIT 100
  `;

  // 3. Concentration alerts (single recipient > 25% of program)
  const concentrationQuery = `
    WITH program_totals AS (
      SELECT
        prog_name_en,
        SUM(agreement_value) as program_total
      FROM grants_contributions
      ${addCondition('prog_name_en IS NOT NULL')}
      GROUP BY prog_name_en
      HAVING SUM(agreement_value) > 0
    ),
    recipient_program_totals AS (
      SELECT
        g.recipient_legal_name,
        g.prog_name_en,
        SUM(g.agreement_value) as recipient_total,
        p.program_total
      FROM grants_contributions g
      JOIN program_totals p ON g.prog_name_en = p.prog_name_en
      ${whereClause ? whereClause : ''}
      GROUP BY g.recipient_legal_name, g.prog_name_en, p.program_total
    )
    SELECT
      recipient_legal_name,
      prog_name_en,
      recipient_total,
      program_total,
      (recipient_total / NULLIF(program_total, 0) * 100) as share_pct
    FROM recipient_program_totals
    WHERE program_total > 0 AND (recipient_total / NULLIF(program_total, 0)) > 0.25
    ORDER BY share_pct DESC
    LIMIT 50
  `;

  // 4. Rapid project alerts (high value + short duration)
  const rapidProjectQuery = `
    SELECT
      _id,
      ref_number,
      recipient_legal_name,
      prog_name_en,
      agreement_value,
      agreement_start_date,
      agreement_end_date,
      (agreement_end_date::date - agreement_start_date::date) as duration_days
    FROM grants_contributions
    ${addCondition(`agreement_value >= 100000
    AND agreement_start_date IS NOT NULL
    AND agreement_end_date IS NOT NULL
    AND (agreement_end_date::date - agreement_start_date::date) < 30`)}
    ORDER BY agreement_value DESC
    LIMIT 50
  `;

  // 5. March rush (FYE agreements)
  const marchRushQuery = `
    SELECT
      _id,
      ref_number,
      recipient_legal_name,
      prog_name_en,
      agreement_value,
      agreement_start_date,
      EXTRACT(YEAR FROM agreement_start_date::date) as year,
      EXTRACT(DAY FROM agreement_start_date::date) as day_of_march
    FROM grants_contributions
    ${addCondition(`agreement_start_date IS NOT NULL
    AND EXTRACT(MONTH FROM agreement_start_date::date) = 3
    AND EXTRACT(DAY FROM agreement_start_date::date) >= 20
    AND agreement_value >= 50000`)}
    ORDER BY agreement_start_date DESC, agreement_value DESC
    LIMIT 100
  `;

  try {
    const [outlierResult, thresholdResult, concentrationResult, rapidProjectResult, marchRushResult] = await Promise.all([
      pool.query(outlierQuery, params),
      pool.query(thresholdQuery, params),
      pool.query(concentrationQuery, params),
      pool.query(rapidProjectQuery, params),
      pool.query(marchRushQuery, params)
    ]);

    return {
      statistical_outliers: {
        count: outlierResult.rows.length,
        severity: outlierResult.rows.length > 10 ? 'High' : outlierResult.rows.length > 5 ? 'Medium' : 'Low',
        items: outlierResult.rows.map(row => ({
          _id: row._id,
          ref_number: row.ref_number,
          recipient_legal_name: row.recipient_legal_name,
          prog_name_en: row.prog_name_en,
          agreement_value: parseFloat(row.agreement_value),
          mean_value: parseFloat(row.mean_value),
          z_score: parseFloat(row.z_score).toFixed(2),
          alert_type: 'Statistical Outlier'
        }))
      },
      threshold_gaming: {
        count: thresholdResult.rows.length,
        severity: thresholdResult.rows.length > 20 ? 'High' : thresholdResult.rows.length > 10 ? 'Medium' : 'Low',
        items: thresholdResult.rows.map(row => ({
          _id: row._id,
          ref_number: row.ref_number,
          recipient_legal_name: row.recipient_legal_name,
          prog_name_en: row.prog_name_en,
          agreement_value: parseFloat(row.agreement_value),
          threshold_indicator: row.threshold_indicator,
          alert_type: 'Threshold Gaming'
        }))
      },
      concentration_alerts: {
        count: concentrationResult.rows.length,
        severity: concentrationResult.rows.length > 15 ? 'High' : concentrationResult.rows.length > 5 ? 'Medium' : 'Low',
        items: concentrationResult.rows.map(row => ({
          recipient_legal_name: row.recipient_legal_name,
          prog_name_en: row.prog_name_en,
          recipient_total: parseFloat(row.recipient_total),
          program_total: parseFloat(row.program_total),
          share_pct: parseFloat(row.share_pct).toFixed(2),
          alert_type: 'High Concentration'
        }))
      },
      rapid_projects: {
        count: rapidProjectResult.rows.length,
        severity: rapidProjectResult.rows.length > 10 ? 'High' : rapidProjectResult.rows.length > 3 ? 'Medium' : 'Low',
        items: rapidProjectResult.rows.map(row => ({
          _id: row._id,
          ref_number: row.ref_number,
          recipient_legal_name: row.recipient_legal_name,
          prog_name_en: row.prog_name_en,
          agreement_value: parseFloat(row.agreement_value),
          agreement_start_date: row.agreement_start_date,
          agreement_end_date: row.agreement_end_date,
          duration_days: parseInt(row.duration_days),
          alert_type: 'Rapid Project'
        }))
      },
      fiscal_year_end_rush: {
        count: marchRushResult.rows.length,
        severity: marchRushResult.rows.length > 30 ? 'High' : marchRushResult.rows.length > 15 ? 'Medium' : 'Low',
        items: marchRushResult.rows.map(row => ({
          _id: row._id,
          ref_number: row.ref_number,
          recipient_legal_name: row.recipient_legal_name,
          prog_name_en: row.prog_name_en,
          agreement_value: parseFloat(row.agreement_value),
          agreement_start_date: row.agreement_start_date,
          year: parseInt(row.year),
          day_of_march: parseInt(row.day_of_march),
          alert_type: 'FYE Rush'
        }))
      },
      summary: {
        total_alerts: outlierResult.rows.length + thresholdResult.rows.length + concentrationResult.rows.length + rapidProjectResult.rows.length + marchRushResult.rows.length,
        by_severity: {
          high: [outlierResult, thresholdResult, concentrationResult, rapidProjectResult, marchRushResult]
            .filter(r => r.rows.length > 10).length,
          medium: [outlierResult, thresholdResult, concentrationResult, rapidProjectResult, marchRushResult]
            .filter(r => r.rows.length > 5 && r.rows.length <= 10).length,
          low: [outlierResult, thresholdResult, concentrationResult, rapidProjectResult, marchRushResult]
            .filter(r => r.rows.length <= 5).length
        }
      }
    };
  } catch (error) {
    console.error('Anomaly detection error:', error);
    return {
      statistical_outliers: { count: 0, severity: 'Low', items: [] },
      threshold_gaming: { count: 0, severity: 'Low', items: [] },
      concentration_alerts: { count: 0, severity: 'Low', items: [] },
      rapid_projects: { count: 0, severity: 'Low', items: [] },
      fiscal_year_end_rush: { count: 0, severity: 'Low', items: [] },
      summary: { total_alerts: 0, by_severity: { high: 0, medium: 0, low: 0 } }
    };
  }
};

// ==================== 12. RECIPIENT PROFILE ====================

/**
 * Get detailed profile for a specific recipient
 */
exports.getRecipientProfile = async (recipientName, filters = {}) => {
  const baseFilters = { ...filters };
  const { whereClause: baseWhere, params: baseParams } = buildWhereClause(baseFilters);

  const additionalWhere = baseWhere ? `${baseWhere} AND` : 'WHERE';
  const params = [...baseParams, recipientName];
  const recipientParamIndex = baseParams.length + 1;

  // Basic recipient info
  const basicQuery = `
    SELECT
      recipient_legal_name,
      recipient_operating_name,
      recipient_business_number,
      recipient_type,
      recipient_city,
      recipient_province,
      recipient_postal_code,
      COUNT(*) as total_agreements,
      SUM(agreement_value) as total_value,
      AVG(agreement_value) as avg_value,
      MIN(agreement_start_date) as first_agreement,
      MAX(agreement_start_date) as latest_agreement,
      COUNT(DISTINCT prog_name_en) as program_count,
      COUNT(DISTINCT owner_org_title) as department_count,
      COUNT(CASE WHEN amendment_number IS NOT NULL AND amendment_number != '' AND amendment_number != '0' THEN 1 END) as amendment_count
    FROM grants_contributions
    ${additionalWhere} recipient_legal_name = $${recipientParamIndex}
    GROUP BY recipient_legal_name, recipient_operating_name, recipient_business_number, recipient_type,
             recipient_city, recipient_province, recipient_postal_code
  `;

  // Agreement history
  const historyQuery = `
    SELECT
      _id,
      ref_number,
      prog_name_en,
      owner_org_title,
      agreement_value,
      agreement_start_date,
      agreement_end_date,
      agreement_type,
      amendment_number,
      description_en
    FROM grants_contributions
    ${additionalWhere} recipient_legal_name = $${recipientParamIndex}
    ORDER BY agreement_start_date DESC
    LIMIT 100
  `;

  // Program participation
  const programsQuery = `
    SELECT
      prog_name_en,
      owner_org_title,
      COUNT(*) as agreement_count,
      SUM(agreement_value) as total_value,
      MIN(agreement_start_date) as first_received,
      MAX(agreement_start_date) as last_received
    FROM grants_contributions
    ${additionalWhere} recipient_legal_name = $${recipientParamIndex}
    GROUP BY prog_name_en, owner_org_title
    ORDER BY total_value DESC
  `;

  const [basicResult, historyResult, programsResult] = await Promise.all([
    pool.query(basicQuery, params),
    pool.query(historyQuery, params),
    pool.query(programsQuery, params)
  ]);

  if (basicResult.rows.length === 0) {
    return null;
  }

  const basic = basicResult.rows[0];

  return {
    recipient_info: {
      recipient_legal_name: basic.recipient_legal_name,
      recipient_operating_name: basic.recipient_operating_name,
      recipient_business_number: basic.recipient_business_number,
      recipient_type: basic.recipient_type,
      recipient_city: basic.recipient_city,
      recipient_province: basic.recipient_province,
      recipient_postal_code: basic.recipient_postal_code
    },
    funding_summary: {
      total_agreements: parseInt(basic.total_agreements),
      total_value: parseFloat(basic.total_value),
      avg_value: parseFloat(basic.avg_value),
      first_agreement: basic.first_agreement,
      latest_agreement: basic.latest_agreement,
      program_count: parseInt(basic.program_count),
      department_count: parseInt(basic.department_count),
      amendment_count: parseInt(basic.amendment_count),
      amendment_rate: (parseInt(basic.amendment_count) / parseInt(basic.total_agreements)) * 100
    },
    agreement_history: historyResult.rows.map(row => ({
      _id: row._id,
      ref_number: row.ref_number,
      prog_name_en: row.prog_name_en,
      owner_org_title: row.owner_org_title,
      agreement_value: parseFloat(row.agreement_value),
      agreement_start_date: row.agreement_start_date,
      agreement_end_date: row.agreement_end_date,
      agreement_type: row.agreement_type,
      has_amendment: row.amendment_number ? true : false,
      description_en: row.description_en
    })),
    program_participation: programsResult.rows.map(row => ({
      prog_name_en: row.prog_name_en,
      owner_org_title: row.owner_org_title,
      agreement_count: parseInt(row.agreement_count),
      total_value: parseFloat(row.total_value),
      first_received: row.first_received,
      last_received: row.last_received
    }))
  };
};

// ==================== 13. RECIPIENT SEARCH ====================

/**
 * Comprehensive recipient search with year-over-year analysis
 */
exports.getRecipientSearch = async (searchTerm, filters = {}) => {
  if (!searchTerm || searchTerm.trim().length < 2) {
    return {
      matching_recipients: [],
      grants: [],
      year_over_year: [],
      summary: {
        total_grants: 0,
        total_value: 0,
        unique_recipients: 0,
        date_range: { earliest: null, latest: null }
      }
    };
  }

  const searchPattern = `%${searchTerm.trim()}%`;
  const { whereClause: filterWhere, params: filterParams } = buildWhereClause(filters);

  // Build WHERE clause for search (search uses $1)
  const searchConditions = [
    'recipient_business_number ILIKE $1',
    'recipient_legal_name ILIKE $1',
    'recipient_operating_name ILIKE $1',
    'research_organization_name ILIKE $1'
  ];

  const searchWhere = `(${searchConditions.join(' OR ')})`;

  // If we have filters, we need to renumber their placeholders
  let combinedWhere = `WHERE ${searchWhere}`;
  let allParams = [searchPattern];

  if (filterWhere && filterParams.length > 0) {
    // Renumber filter placeholders to start after the search parameter
    let adjustedFilterWhere = filterWhere.replace('WHERE ', '');

    // Replace $1, $2, $3... with $2, $3, $4... (offset by 1)
    for (let i = filterParams.length; i >= 1; i--) {
      const oldPlaceholder = `$${i}`;
      const newPlaceholder = `$${i + 1}`;
      adjustedFilterWhere = adjustedFilterWhere.split(oldPlaceholder).join(newPlaceholder);
    }

    combinedWhere = `WHERE ${searchWhere} AND ${adjustedFilterWhere}`;
    allParams = [searchPattern, ...filterParams];
  }

  // 1. Get matching recipients summary
  const recipientsQuery = `
    SELECT DISTINCT
      recipient_legal_name,
      recipient_operating_name,
      recipient_business_number,
      recipient_type,
      recipient_city,
      recipient_province,
      COUNT(*) OVER (PARTITION BY recipient_legal_name) as grant_count,
      SUM(agreement_value) OVER (PARTITION BY recipient_legal_name) as total_value
    FROM grants_contributions
    ${combinedWhere}
    ORDER BY total_value DESC
    LIMIT 50
  `;

  // 2. Get detailed grants list
  const grantsQuery = `
    SELECT
      _id,
      ref_number,
      recipient_legal_name,
      recipient_operating_name,
      recipient_business_number,
      recipient_type,
      recipient_city,
      recipient_province,
      prog_name_en,
      owner_org_title,
      agreement_type,
      agreement_value,
      agreement_start_date,
      agreement_end_date,
      agreement_title_en,
      description_en,
      expected_results_en,
      amendment_number,
      amendment_date
    FROM grants_contributions
    ${combinedWhere}
    ORDER BY agreement_start_date DESC, agreement_value DESC
    LIMIT 1000
  `;

  // 3. Year-over-year analysis
  const yoyQuery = `
    SELECT
      CASE
        WHEN EXTRACT(MONTH FROM agreement_start_date::date) >= 4
        THEN EXTRACT(YEAR FROM agreement_start_date::date)
        ELSE EXTRACT(YEAR FROM agreement_start_date::date) - 1
      END as fiscal_year,
      COUNT(*) as grant_count,
      SUM(agreement_value) as total_value,
      AVG(agreement_value) as avg_value,
      COUNT(DISTINCT prog_name_en) as unique_programs,
      COUNT(DISTINCT owner_org_title) as unique_departments,
      COUNT(DISTINCT recipient_legal_name) as unique_recipients
    FROM grants_contributions
    ${combinedWhere}
    AND agreement_start_date IS NOT NULL
    GROUP BY fiscal_year
    ORDER BY fiscal_year DESC
  `;

  // 4. Summary statistics
  const summaryQuery = `
    SELECT
      COUNT(*) as total_grants,
      SUM(agreement_value) as total_value,
      COUNT(DISTINCT recipient_legal_name) as unique_recipients,
      MIN(agreement_start_date) as earliest_date,
      MAX(agreement_start_date) as latest_date,
      COUNT(DISTINCT prog_name_en) as unique_programs,
      COUNT(DISTINCT owner_org_title) as unique_departments
    FROM grants_contributions
    ${combinedWhere}
  `;

  try {
    const [recipientsResult, grantsResult, yoyResult, summaryResult] = await Promise.all([
      pool.query(recipientsQuery, allParams),
      pool.query(grantsQuery, allParams),
      pool.query(yoyQuery, allParams),
      pool.query(summaryQuery, allParams)
    ]);

    const summary = summaryResult.rows[0];

    return {
      matching_recipients: recipientsResult.rows.map(row => ({
        recipient_legal_name: row.recipient_legal_name,
        recipient_operating_name: row.recipient_operating_name,
        recipient_business_number: row.recipient_business_number,
        recipient_type: row.recipient_type,
        recipient_city: row.recipient_city,
        recipient_province: row.recipient_province,
        grant_count: parseInt(row.grant_count),
        total_value: parseFloat(row.total_value)
      })),
      grants: grantsResult.rows.map(row => ({
        _id: row._id,
        ref_number: row.ref_number,
        recipient_legal_name: row.recipient_legal_name,
        recipient_operating_name: row.recipient_operating_name,
        recipient_business_number: row.recipient_business_number,
        recipient_type: row.recipient_type,
        recipient_city: row.recipient_city,
        recipient_province: row.recipient_province,
        prog_name_en: row.prog_name_en,
        owner_org_title: row.owner_org_title,
        agreement_type: row.agreement_type,
        agreement_value: parseFloat(row.agreement_value),
        agreement_start_date: row.agreement_start_date,
        agreement_end_date: row.agreement_end_date,
        agreement_title_en: row.agreement_title_en,
        description_en: row.description_en,
        expected_results_en: row.expected_results_en,
        amendment_number: row.amendment_number,
        amendment_date: row.amendment_date
      })),
      year_over_year: yoyResult.rows.map(row => ({
        fiscal_year: row.fiscal_year,
        grant_count: parseInt(row.grant_count),
        total_value: parseFloat(row.total_value),
        avg_value: parseFloat(row.avg_value),
        unique_programs: parseInt(row.unique_programs),
        unique_departments: parseInt(row.unique_departments),
        unique_recipients: parseInt(row.unique_recipients)
      })),
      summary: {
        total_grants: parseInt(summary.total_grants),
        total_value: parseFloat(summary.total_value) || 0,
        unique_recipients: parseInt(summary.unique_recipients),
        unique_programs: parseInt(summary.unique_programs),
        unique_departments: parseInt(summary.unique_departments),
        date_range: {
          earliest: summary.earliest_date,
          latest: summary.latest_date
        }
      }
    };
  } catch (error) {
    console.error('Recipient search error:', error);
    throw error;
  }
};

module.exports = exports;
