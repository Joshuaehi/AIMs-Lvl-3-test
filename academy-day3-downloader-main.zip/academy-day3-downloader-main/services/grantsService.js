const pool = require('../config/database');
const { buildPaginationQuery, buildFieldSelection, buildSortClause, buildFilterClause } = require('../utils/queryBuilder');

// Default fields to select
const DEFAULT_FIELDS = [
  '_id', 'ref_number', 'agreement_type', 'recipient_legal_name',
  'recipient_province', 'recipient_city', 'agreement_value',
  'agreement_start_date', 'agreement_end_date', 'prog_name_en', 'description_en'
];

const ALL_FIELDS = [
  '_id', 'ref_number', 'amendment_number', 'amendment_date', 'agreement_type',
  'recipient_type', 'recipient_business_number', 'recipient_legal_name',
  'recipient_operating_name', 'research_organization_name', 'recipient_country',
  'recipient_province', 'recipient_city', 'recipient_postal_code',
  'federal_riding_name_en', 'federal_riding_name_fr', 'federal_riding_number',
  'prog_name_en', 'prog_name_fr', 'prog_purpose_en', 'prog_purpose_fr',
  'agreement_title_en', 'agreement_title_fr', 'agreement_number',
  'agreement_value', 'foreign_currency_type', 'foreign_currency_value',
  'agreement_start_date', 'agreement_end_date', 'coverage',
  'description_en', 'description_fr', 'naics_identifier',
  'expected_results_en', 'expected_results_fr',
  'additional_information_en', 'additional_information_fr',
  'owner_org', 'owner_org_title'
];

/**
 * Get all grants with filtering, sorting, and pagination
 */
exports.getAllGrants = async (filters = {}, options = {}) => {
  const { page, limit, offset, sort, fields } = options;

  const allowedFields = ALL_FIELDS;
  const allowedFilters = {
    province: { column: 'recipient_province', operator: '=' },
    agreement_type: { column: 'agreement_type', operator: '=' },
    start_date_from: { column: 'agreement_start_date', operator: '>=' },
    start_date_to: { column: 'agreement_start_date', operator: '<=' },
    end_date_from: { column: 'agreement_end_date', operator: '>=' },
    end_date_to: { column: 'agreement_end_date', operator: '<=' },
    value_min: { column: 'agreement_value', operator: '>=' },
    value_max: { column: 'agreement_value', operator: '<=' },
    country: { column: 'recipient_country', operator: '=' },
    city: { column: 'recipient_city', operator: 'LIKE' },
    program: { column: 'prog_name_en', operator: 'LIKE' }
  };

  const selectedFields = buildFieldSelection(allowedFields, fields);
  const { whereClause, params, paramIndex } = buildFilterClause(filters, allowedFilters);
  const sortClause = buildSortClause(allowedFields, sort);

  // Get total count
  const countQuery = `SELECT COUNT(*) FROM grants_contributions ${whereClause}`;
  const countResult = await pool.query(countQuery, params);
  const total = parseInt(countResult.rows[0].count);

  // Build and execute main query
  const baseQuery = `
    SELECT ${selectedFields}
    FROM grants_contributions
    ${whereClause}
    ${sortClause}
  `;

  const paginationInfo = buildPaginationQuery(baseQuery, { page, limit, offset });

  // Replace placeholders with actual param indices
  let finalQuery = paginationInfo.query;
  finalQuery = finalQuery.replace('$LIMIT$', `$${paramIndex}`);
  finalQuery = finalQuery.replace('$OFFSET$', `$${paramIndex + 1}`);

  const allParams = [...params, paginationInfo.params[0], paginationInfo.params[1]];
  const result = await pool.query(finalQuery, allParams);

  return {
    data: result.rows,
    total,
    limit: paginationInfo.limit,
    offset: paginationInfo.offset
  };
};

/**
 * Get grant by ID
 */
exports.getGrantById = async (id) => {
  const query = 'SELECT * FROM grants_contributions WHERE _id = $1';
  const result = await pool.query(query, [id]);
  return result.rows[0];
};

/**
 * Search grants by text (recipient name, program name, description)
 */
exports.searchGrants = async (searchTerm, options = {}) => {
  const { page, limit, offset } = options;

  // Count total matching results
  const countQuery = `
    SELECT COUNT(*)
    FROM grants_contributions
    WHERE
      to_tsvector('english', recipient_legal_name) @@ plainto_tsquery('english', $1)
      OR to_tsvector('english', prog_name_en) @@ plainto_tsquery('english', $1)
      OR recipient_legal_name ILIKE $2
      OR prog_name_en ILIKE $2
  `;
  const countResult = await pool.query(countQuery, [searchTerm, `%${searchTerm}%`]);
  const total = parseInt(countResult.rows[0].count);

  // Get paginated results
  const searchQuery = `
    SELECT ${DEFAULT_FIELDS.join(', ')}
    FROM grants_contributions
    WHERE
      to_tsvector('english', recipient_legal_name) @@ plainto_tsquery('english', $1)
      OR to_tsvector('english', prog_name_en) @@ plainto_tsquery('english', $1)
      OR recipient_legal_name ILIKE $2
      OR prog_name_en ILIKE $2
    ORDER BY agreement_start_date DESC
  `;

  const paginationInfo = buildPaginationQuery(searchQuery, { page, limit, offset });

  let finalQuery = paginationInfo.query;
  finalQuery = finalQuery.replace('$LIMIT$', '$3');
  finalQuery = finalQuery.replace('$OFFSET$', '$4');

  const result = await pool.query(finalQuery, [
    searchTerm,
    `%${searchTerm}%`,
    paginationInfo.params[0],
    paginationInfo.params[1]
  ]);

  return {
    data: result.rows,
    total,
    limit: paginationInfo.limit,
    offset: paginationInfo.offset
  };
};

/**
 * Get statistics about grants
 */
exports.getGrantsStats = async () => {
  const statsQuery = `
    SELECT
      COUNT(*) as total_grants,
      SUM(CASE WHEN agreement_type = 'G' THEN 1 ELSE 0 END) as total_grants_type,
      SUM(CASE WHEN agreement_type = 'C' THEN 1 ELSE 0 END) as total_contributions,
      SUM(agreement_value) as total_value,
      AVG(agreement_value) as average_value,
      MAX(agreement_value) as max_value,
      MIN(agreement_value) as min_value,
      COUNT(DISTINCT recipient_province) as provinces_count,
      COUNT(DISTINCT prog_name_en) as programs_count
    FROM grants_contributions
  `;

  const provinceQuery = `
    SELECT recipient_province, COUNT(*) as count, SUM(agreement_value) as total_value
    FROM grants_contributions
    WHERE recipient_province IS NOT NULL
    GROUP BY recipient_province
    ORDER BY count DESC
    LIMIT 15
  `;

  const typeQuery = `
    SELECT
      agreement_type,
      COUNT(*) as count,
      SUM(agreement_value) as total_value
    FROM grants_contributions
    WHERE agreement_type IS NOT NULL
    GROUP BY agreement_type
  `;

  const [statsResult, provinceResult, typeResult] = await Promise.all([
    pool.query(statsQuery),
    pool.query(provinceQuery),
    pool.query(typeQuery)
  ]);

  return {
    overview: statsResult.rows[0],
    by_province: provinceResult.rows,
    by_type: typeResult.rows
  };
};

/**
 * Get aggregated statistics with filters
 */
exports.getFilteredStats = async (filters = {}) => {
  const { province, agreement_type, start_date_from, start_date_to, value_min, value_max } = filters;

  const conditions = [];
  const params = [];
  let paramIndex = 1;

  if (province) {
    conditions.push(`recipient_province = $${paramIndex++}`);
    params.push(province);
  }

  if (agreement_type) {
    conditions.push(`agreement_type = $${paramIndex++}`);
    params.push(agreement_type);
  }

  if (start_date_from) {
    conditions.push(`agreement_start_date >= $${paramIndex++}`);
    params.push(start_date_from);
  }

  if (start_date_to) {
    conditions.push(`agreement_start_date <= $${paramIndex++}`);
    params.push(start_date_to);
  }

  if (value_min) {
    conditions.push(`agreement_value >= $${paramIndex++}`);
    params.push(value_min);
  }

  if (value_max) {
    conditions.push(`agreement_value <= $${paramIndex++}`);
    params.push(value_max);
  }

  const whereClause = conditions.length > 0 ? `WHERE ${conditions.join(' AND ')}` : '';

  // Overall statistics
  const statsQuery = `
    SELECT
      COUNT(*) as total_count,
      SUM(agreement_value) as total_value,
      AVG(agreement_value) as average_value,
      MAX(agreement_value) as max_value,
      MIN(agreement_value) as min_value,
      COUNT(DISTINCT prog_name_en) as unique_programs
    FROM grants_contributions
    ${whereClause}
  `;

  // By program
  const programQuery = `
    SELECT
      prog_name_en,
      COUNT(*) as count,
      SUM(agreement_value) as total_value,
      AVG(agreement_value) as average_value
    FROM grants_contributions
    ${whereClause}
    GROUP BY prog_name_en
    ORDER BY total_value DESC
    LIMIT 20
  `;

  // By type
  const typeQuery = `
    SELECT
      agreement_type,
      COUNT(*) as count,
      SUM(agreement_value) as total_value
    FROM grants_contributions
    ${whereClause}
    GROUP BY agreement_type
  `;

  const [statsResult, programResult, typeResult] = await Promise.all([
    pool.query(statsQuery, params),
    pool.query(programQuery, params),
    pool.query(typeQuery, params)
  ]);

  return {
    overview: statsResult.rows[0],
    by_program: programResult.rows,
    by_type: typeResult.rows
  };
};

/**
 * Get grants by date range for timeline visualization
 */
exports.getGrantsTimeline = async (filters = {}) => {
  const { province, agreement_type, start_date, end_date } = filters;

  const conditions = [];
  const params = [];
  let paramIndex = 1;

  if (province) {
    conditions.push(`recipient_province = $${paramIndex++}`);
    params.push(province);
  }

  if (agreement_type) {
    conditions.push(`agreement_type = $${paramIndex++}`);
    params.push(agreement_type);
  }

  if (start_date) {
    conditions.push(`agreement_start_date >= $${paramIndex++}`);
    params.push(start_date);
  }

  if (end_date) {
    conditions.push(`agreement_end_date <= $${paramIndex++}`);
    params.push(end_date);
  }

  // Always include date checks as part of conditions
  conditions.push('agreement_start_date IS NOT NULL');
  conditions.push('agreement_end_date IS NOT NULL');

  const whereClause = conditions.length > 0 ? `WHERE ${conditions.join(' AND ')}` : '';

  const query = `
    SELECT
      _id,
      recipient_legal_name,
      agreement_value,
      agreement_start_date,
      agreement_end_date,
      prog_name_en,
      recipient_province
    FROM grants_contributions
    ${whereClause}
    ORDER BY agreement_value DESC, agreement_start_date ASC
    LIMIT 100
  `;

  const result = await pool.query(query, params);
  return result.rows;
};
