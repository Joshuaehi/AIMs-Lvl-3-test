const swaggerJsdoc = require('swagger-jsdoc');
const swaggerUi = require('swagger-ui-express');

const options = {
  definition: {
    openapi: '3.0.0',
    info: {
      title: 'Canada Grants and Contributions API',
      version: '1.0.0',
      description: 'RESTful API for exploring Government of Canada Grants and Contributions data',
      contact: {
        name: 'API Support'
      }
    },
    servers: [
      {
        url: `http://localhost:${process.env.PORT || 3000}/api/${process.env.API_VERSION || 'v1'}`,
        description: 'Development server'
      }
    ],
    components: {
      schemas: {
        Grant: {
          type: 'object',
          properties: {
            _id: { type: 'integer', description: 'Unique identifier' },
            ref_number: { type: 'string', description: 'Reference number' },
            agreement_type: { type: 'string', enum: ['G', 'C', 'O'], description: 'Agreement type (G=Grant, C=Contribution, O=Other)' },
            recipient_legal_name: { type: 'string', description: 'Recipient legal name' },
            recipient_province: { type: 'string', description: 'Province code (e.g., AB, ON)' },
            recipient_city: { type: 'string', description: 'City name' },
            agreement_value: { type: 'number', description: 'Agreement value in CAD' },
            agreement_start_date: { type: 'string', format: 'date', description: 'Start date' },
            agreement_end_date: { type: 'string', format: 'date', description: 'End date' },
            prog_name_en: { type: 'string', description: 'Program name (English)' },
            prog_name_fr: { type: 'string', description: 'Program name (French)' },
            description_en: { type: 'string', description: 'Description (English)' },
            description_fr: { type: 'string', description: 'Description (French)' }
          }
        }
      },
      parameters: {
        limitParam: {
          in: 'query',
          name: 'limit',
          schema: { type: 'integer', default: 50, maximum: 1000 },
          description: 'Number of records per page'
        },
        pageParam: {
          in: 'query',
          name: 'page',
          schema: { type: 'integer', default: 1, minimum: 1 },
          description: 'Page number'
        },
        offsetParam: {
          in: 'query',
          name: 'offset',
          schema: { type: 'integer', default: 0, minimum: 0 },
          description: 'Number of records to skip'
        },
        sortParam: {
          in: 'query',
          name: 'sort',
          schema: { type: 'string' },
          description: 'Sort field (prefix with - for descending)'
        },
        fieldsParam: {
          in: 'query',
          name: 'fields',
          schema: { type: 'string' },
          description: 'Comma-separated list of fields to return'
        }
      },
      responses: {
        NotFound: {
          description: 'Resource not found',
          content: {
            'application/json': {
              schema: {
                type: 'object',
                properties: {
                  success: { type: 'boolean', example: false },
                  error: {
                    type: 'object',
                    properties: {
                      message: { type: 'string' },
                      code: { type: 'string' }
                    }
                  }
                }
              }
            }
          }
        },
        BadRequest: {
          description: 'Invalid request parameters',
          content: {
            'application/json': {
              schema: {
                type: 'object',
                properties: {
                  success: { type: 'boolean', example: false },
                  error: {
                    type: 'object',
                    properties: {
                      message: { type: 'string' },
                      code: { type: 'string' }
                    }
                  }
                }
              }
            }
          }
        },
        ServerError: {
          description: 'Internal server error',
          content: {
            'application/json': {
              schema: {
                type: 'object',
                properties: {
                  success: { type: 'boolean', example: false },
                  error: {
                    type: 'object',
                    properties: {
                      message: { type: 'string' },
                      code: { type: 'string' }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  },
  apis: ['./routes/*.js', './controllers/*.js']
};

const swaggerSpec = swaggerJsdoc(options);

module.exports = {
  swaggerUi,
  swaggerSpec
};
