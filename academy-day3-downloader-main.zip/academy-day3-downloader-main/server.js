require('dotenv').config();
const express = require('express');
const helmet = require('helmet');
const cors = require('cors');
const morgan = require('morgan');
const path = require('path');
const pool = require('./config/database');
const { swaggerUi, swaggerSpec } = require('./config/swagger');
const { notFoundHandler, globalErrorHandler } = require('./middleware/errorHandler');

const app = express();
const PORT = process.env.PORT || 3000;
const API_VERSION = process.env.API_VERSION || 'v1';

// Security middleware
app.use(helmet({
  contentSecurityPolicy: false,
  crossOriginEmbedderPolicy: false
}));

// CORS configuration (permissive for development)
app.use(cors({
  origin: '*',
  methods: ['GET', 'HEAD', 'OPTIONS', 'POST', 'PUT', 'DELETE'],
  allowedHeaders: ['Content-Type', 'Authorization'],
  credentials: false
}));

// Logging middleware
app.use(morgan(process.env.NODE_ENV === 'development' ? 'dev' : 'combined'));

// Body parsing middleware
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// Serve static files from /public directory
const publicPath = path.join(__dirname, 'public');
app.use(express.static(publicPath, {
  maxAge: '1d',
  etag: true,
  lastModified: true,
  index: false
}));

// Swagger documentation
app.use('/api-docs', swaggerUi.serve);
app.get('/api-docs', swaggerUi.setup(swaggerSpec, {
  customSiteTitle: 'Canada Grants API Documentation',
  customCss: '.swagger-ui .topbar { display: none }'
}));
app.get('/api-docs.json', (req, res) => {
  res.setHeader('Content-Type', 'application/json');
  res.send(swaggerSpec);
});

// API routes
app.use(`/api/${API_VERSION}`, require('./routes'));

// Root endpoint
app.get('/api', (req, res) => {
  res.json({
    success: true,
    message: 'Canada Grants and Contributions API',
    version: '1.0.0',
    documentation: '/api-docs',
    apiDocs: '/api-docs.json',
    endpoints: {
      health: `/api/${API_VERSION}/health`,
      stats: `/api/${API_VERSION}/stats`,
      grants: `/api/${API_VERSION}/grants`,
      search: `/api/${API_VERSION}/grants/search`,
      timeline: `/api/${API_VERSION}/grants/timeline`
    }
  });
});

// Fallback to index.html for SPA routes
app.get('/*', (req, res, next) => {
  // Skip API routes
  if (req.path.startsWith('/api')) {
    return next();
  }

  const indexPath = path.join(publicPath, 'index.html');
  res.sendFile(indexPath, (err) => {
    if (err) {
      next();
    }
  });
});

// Error handling
app.use(notFoundHandler);
app.use(globalErrorHandler);

// Graceful shutdown
process.on('SIGTERM', async () => {
  console.log('SIGTERM signal received: closing HTTP server');
  await pool.end();
  process.exit(0);
});

process.on('SIGINT', async () => {
  console.log('SIGINT signal received: closing HTTP server');
  await pool.end();
  process.exit(0);
});

// Start server
app.listen(PORT, () => {
  console.log(`
================================================================================
    Canada Grants and Contributions Explorer
================================================================================
    Server running on port: ${PORT}
    Environment: ${process.env.NODE_ENV || 'development'}

    Frontend Application:    http://localhost:${PORT}
    API Base URL:            http://localhost:${PORT}/api/${API_VERSION}
    API Documentation:       http://localhost:${PORT}/api-docs
    API Docs JSON:           http://localhost:${PORT}/api-docs.json

    Health Check:            http://localhost:${PORT}/api/${API_VERSION}/health
    Database Stats:          http://localhost:${PORT}/api/${API_VERSION}/stats
================================================================================
  `);
});

module.exports = app;
