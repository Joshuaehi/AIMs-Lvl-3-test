const fs = require('fs');
const path = require('path');

// Type detection functions
function detectType(value) {
  if (value === null || value === undefined || value === '') {
    return 'unknown';
  }

  const str = String(value).trim();

  // Boolean (Y/N)
  if (str === 'Y' || str === 'N') {
    return 'boolean';
  }

  // Date (YYYY-MM-DD or similar)
  if (/^\d{4}[-/]\d{1,2}[-/]\d{1,2}$/.test(str)) {
    return 'date';
  }

  // Integer
  if (/^-?\d+$/.test(str)) {
    return 'integer';
  }

  // Decimal
  if (/^-?\d+\.\d+$/.test(str)) {
    return 'decimal';
  }

  // Default to text
  return 'text';
}

function sqlType(detectedType, maxLength = null) {
  switch (detectedType) {
    case 'boolean':
      return 'BOOLEAN';
    case 'date':
      return 'DATE';
    case 'integer':
      return 'INTEGER';
    case 'decimal':
      return 'DECIMAL(15,2)';
    case 'text':
      if (maxLength && maxLength <= 10) return 'VARCHAR(10)';
      if (maxLength && maxLength <= 50) return 'VARCHAR(50)';
      if (maxLength && maxLength <= 255) return 'VARCHAR(255)';
      return 'TEXT';
    default:
      return 'TEXT';
  }
}

// Analyze schema from cached JSON
function analyzeSchema(resourceId) {
  const filePath = path.join(__dirname, 'data', `${resourceId}.json`);

  if (!fs.existsSync(filePath)) {
    console.error(`Error: Cache file not found: ${filePath}`);
    console.error('Please run download.js first');
    process.exit(1);
  }

  console.log(`Analyzing schema for resource: ${resourceId}`);

  const data = JSON.parse(fs.readFileSync(filePath, 'utf8'));
  const records = data.records;

  if (!records || records.length === 0) {
    console.error('Error: No records found in cache file');
    process.exit(1);
  }

  console.log(`\nAnalyzing ${records.length} records...\n`);

  // Collect field information
  const fields = {};

  // Sample first 1000 records (or all if fewer)
  const sampleSize = Math.min(1000, records.length);

  for (let i = 0; i < sampleSize; i++) {
    const record = records[i];

    for (const [key, value] of Object.entries(record)) {
      if (!fields[key]) {
        fields[key] = {
          name: key,
          types: {},
          nullCount: 0,
          maxLength: 0,
          sampleValues: []
        };
      }

      const field = fields[key];

      if (value === null || value === undefined || value === '') {
        field.nullCount++;
      } else {
        const type = detectType(value);
        field.types[type] = (field.types[type] || 0) + 1;

        const strValue = String(value);
        field.maxLength = Math.max(field.maxLength, strValue.length);

        if (field.sampleValues.length < 5 && !field.sampleValues.includes(strValue)) {
          field.sampleValues.push(strValue);
        }
      }
    }
  }

  // Determine best type for each field
  console.log('Field Analysis:\n');
  console.log('Field Name'.padEnd(35) + ' | Type'.padEnd(20) + ' | Nullable | Sample Values');
  console.log('-'.repeat(120));

  const schema = [];

  for (const field of Object.values(fields)) {
    // Determine predominant type
    const typeEntries = Object.entries(field.types);
    typeEntries.sort((a, b) => b[1] - a[1]);

    const predominantType = typeEntries.length > 0 ? typeEntries[0][0] : 'text';
    const pgType = sqlType(predominantType, field.maxLength);
    const nullable = field.nullCount > 0 ? 'YES' : 'NO';

    schema.push({
      name: field.name,
      type: pgType,
      nullable: nullable === 'YES'
    });

    console.log(
      field.name.padEnd(35) + ' | ' +
      pgType.padEnd(18) + ' | ' +
      nullable.padEnd(8) + ' | ' +
      field.sampleValues.slice(0, 3).join(', ').substring(0, 50)
    );
  }

  // Generate suggested table name
  const tableName = `grants_contributions`;

  console.log('\n' + '='.repeat(120));
  console.log(`\nSuggested table name: ${tableName}`);
  console.log(`Total fields: ${schema.length}`);
  console.log(`Sample size analyzed: ${sampleSize} records`);
  console.log(`Total records in dataset: ${records.length}`);

  return { tableName, schema, records };
}

// Export for use in other scripts
module.exports = { analyzeSchema };

// If run directly, analyze specified resource
if (require.main === module) {
  const resourceId = process.argv[2];

  if (!resourceId) {
    console.error('Usage: node analyze-schema.js <resource_id>');
    process.exit(1);
  }

  analyzeSchema(resourceId);
}
