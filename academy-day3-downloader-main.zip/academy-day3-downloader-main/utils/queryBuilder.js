/**
 * Build pagination query with LIMIT and OFFSET
 */
exports.buildPaginationQuery = (baseQuery, { page = 1, limit = 50, offset }) => {
  const actualLimit = Math.min(parseInt(limit) || 50, 1000);
  const actualOffset = offset !== undefined
    ? parseInt(offset)
    : (parseInt(page) - 1) * actualLimit;

  return {
    query: `${baseQuery} LIMIT $LIMIT$ OFFSET $OFFSET$`,
    params: [actualLimit, actualOffset],
    limit: actualLimit,
    offset: actualOffset
  };
};

/**
 * Build field selection clause
 */
exports.buildFieldSelection = (allowedFields, requestedFields) => {
  if (!requestedFields) return allowedFields.join(', ');

  const fields = requestedFields.split(',').map(f => f.trim());
  const validFields = fields.filter(f => allowedFields.includes(f));

  return validFields.length > 0 ? validFields.join(', ') : allowedFields.join(', ');
};

/**
 * Build ORDER BY clause
 */
exports.buildSortClause = (allowedFields, sortParam) => {
  if (!sortParam) return '';

  const isDescending = sortParam.startsWith('-');
  const field = isDescending ? sortParam.slice(1) : sortParam;

  if (!allowedFields.includes(field)) return '';

  return `ORDER BY ${field} ${isDescending ? 'DESC' : 'ASC'}`;
};

/**
 * Build dynamic WHERE clause from filters
 */
exports.buildFilterClause = (filters, allowedFilters, startParamIndex = 1) => {
  const conditions = [];
  const params = [];
  let paramIndex = startParamIndex;

  for (const [key, value] of Object.entries(filters)) {
    if (allowedFilters[key] && value !== undefined && value !== null && value !== '') {
      const filterConfig = allowedFilters[key];

      if (filterConfig.operator === 'LIKE') {
        conditions.push(`${filterConfig.column} ILIKE $${paramIndex}`);
        params.push(`%${value}%`);
      } else if (filterConfig.operator === 'IN' && Array.isArray(value)) {
        const placeholders = value.map((_, i) => `$${paramIndex + i}`).join(', ');
        conditions.push(`${filterConfig.column} IN (${placeholders})`);
        params.push(...value);
        paramIndex += value.length - 1;
      } else if (filterConfig.operator === '>=') {
        conditions.push(`${filterConfig.column} >= $${paramIndex}`);
        params.push(value);
      } else if (filterConfig.operator === '<=') {
        conditions.push(`${filterConfig.column} <= $${paramIndex}`);
        params.push(value);
      } else {
        const operator = filterConfig.operator || '=';
        conditions.push(`${filterConfig.column} ${operator} $${paramIndex}`);
        params.push(value);
      }
      paramIndex++;
    }
  }

  return {
    whereClause: conditions.length > 0 ? `WHERE ${conditions.join(' AND ')}` : '',
    params,
    paramIndex
  };
};
