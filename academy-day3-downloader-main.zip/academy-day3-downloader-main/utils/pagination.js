/**
 * Calculate pagination metadata
 */
exports.getPaginationMetadata = (total, page, limit, offset) => {
  const totalPages = Math.ceil(total / limit);
  const currentPage = offset !== undefined
    ? Math.floor(offset / limit) + 1
    : parseInt(page) || 1;

  return {
    page: currentPage,
    limit: parseInt(limit),
    total: parseInt(total),
    totalPages
  };
};
