/**
 * Format successful API response
 */
exports.formatSuccessResponse = (data, metadata = {}) => {
  return {
    success: true,
    data,
    ...metadata
  };
};

/**
 * Format error API response
 */
exports.formatErrorResponse = (message, code = 'ERROR', details = {}) => {
  return {
    success: false,
    error: {
      message,
      code,
      ...details
    }
  };
};
