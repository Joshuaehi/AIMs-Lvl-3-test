const fs = require('fs');
const path = require('path');

// Check the actual data lengths to identify the problematic field
function checkDataLengths() {
  const batchFile = path.join(__dirname, 'data', '1d15a62f-5656-49ad-8c88-f40ce689d831_batch_0.json');

  if (!fs.existsSync(batchFile)) {
    console.error('Batch file not found:', batchFile);
    process.exit(1);
  }

  console.log('📊 Analyzing first batch for field lengths...\n');

  const data = JSON.parse(fs.readFileSync(batchFile, 'utf8'));
  const records = data.records;

  // Track maximum lengths for each field
  const maxLengths = {};
  const sampleValues = {};

  // Analyze first 100 records
  const sampleSize = Math.min(100, records.length);

  for (let i = 0; i < sampleSize; i++) {
    const record = records[i];

    for (const [key, value] of Object.entries(record)) {
      if (value !== null && value !== undefined) {
        const strValue = String(value);
        const length = strValue.length;

        if (!maxLengths[key] || length > maxLengths[key].length) {
          maxLengths[key] = {
            length: length,
            value: strValue.substring(0, 100) // First 100 chars for display
          };
        }
      }
    }
  }

  // Check records around position 2500 (where error occurred)
  console.log('🔍 Checking record at position 2500 (where error occurred):\n');
  if (records[2499]) {
    const problemRecord = records[2499];

    console.log('Fields with length > 10 characters:');
    console.log('='.repeat(80));

    for (const [key, value] of Object.entries(problemRecord)) {
      if (value !== null && value !== undefined) {
        const strValue = String(value);
        if (strValue.length > 10) {
          console.log(`\n${key}:`);
          console.log(`  Length: ${strValue.length}`);
          console.log(`  Value: ${strValue.substring(0, 200)}${strValue.length > 200 ? '...' : ''}`);
        }
      }
    }
  }

  // Report fields that exceed VARCHAR(10)
  console.log('\n\n📏 Maximum field lengths across sample:');
  console.log('='.repeat(80));

  const sortedFields = Object.entries(maxLengths)
    .sort((a, b) => b[1].length - a[1].length);

  for (const [field, info] of sortedFields) {
    if (info.length > 10) {
      console.log(`\n${field}:`);
      console.log(`  Max Length: ${info.length}`);
      console.log(`  Sample: ${info.value}`);
    }
  }

  // Identify VARCHAR(10) fields that will fail
  console.log('\n\n⚠️  Fields that will fail with VARCHAR(10):');
  console.log('='.repeat(80));

  const varchar10Fields = [
    'agreement_type',
    'recipient_country',
    'recipient_province',
    'foreign_currency_type'
  ];

  for (const field of varchar10Fields) {
    if (maxLengths[field]) {
      const maxLen = maxLengths[field].length;
      const status = maxLen <= 10 ? '✓ OK' : '❌ TOO LONG';
      console.log(`${field.padEnd(30)} Max: ${maxLen.toString().padStart(3)} chars  ${status}`);

      if (maxLen > 10) {
        console.log(`  Sample value: ${maxLengths[field].value}`);
      }
    }
  }

  console.log('\n💡 Recommendation: Use TEXT instead of VARCHAR(10) for all these fields');
}

// Run check
if (require.main === module) {
  try {
    checkDataLengths();
  } catch (error) {
    console.error('Error:', error.message);
    process.exit(1);
  }
}

module.exports = { checkDataLengths };
