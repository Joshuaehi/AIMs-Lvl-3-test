/**
 * Test script for anomaly detection
 */
const axios = require('axios');

async function testAnomalies() {
  try {
    console.log('Testing anomaly detection endpoint...\n');

    const response = await axios.get('http://localhost:3000/api/v1/analysis/anomalies', {
      params: {
        province: 'AB'
      }
    });

    console.log('✅ Success! Response received\n');
    console.log('Statistical Outliers:', response.data.data.statistical_outliers.count);
    console.log('Threshold Gaming:', response.data.data.threshold_gaming.count);
    console.log('Concentration Alerts:', response.data.data.concentration_alerts.count);
    console.log('Rapid Projects:', response.data.data.rapid_projects.count);
    console.log('FYE Rush:', response.data.data.fiscal_year_end_rush.count);
    console.log('\nTotal Alerts:', response.data.data.summary.total_alerts);

    if (response.data.data.statistical_outliers.count > 0) {
      console.log('\n📊 Sample Outlier:');
      console.log(JSON.stringify(response.data.data.statistical_outliers.items[0], null, 2));
    }

    if (response.data.data.threshold_gaming.count > 0) {
      console.log('\n💰 Sample Threshold Gaming:');
      console.log(JSON.stringify(response.data.data.threshold_gaming.items[0], null, 2));
    }

  } catch (error) {
    console.error('❌ Error:', error.response?.data || error.message);
  }
}

testAnomalies();
