const grantsService = require('../services/grantsService');
const { formatSuccessResponse, formatErrorResponse } = require('../utils/responseFormatter');
const { getPaginationMetadata } = require('../utils/pagination');

/**
 * @swagger
 * /grants:
 *   get:
 *     summary: Get all grants and contributions
 *     tags: [Grants]
 *     parameters:
 *       - $ref: '#/components/parameters/limitParam'
 *       - $ref: '#/components/parameters/pageParam'
 *       - $ref: '#/components/parameters/sortParam'
 *       - $ref: '#/components/parameters/fieldsParam'
 *       - in: query
 *         name: province
 *         schema:
 *           type: string
 *         description: Filter by province code (e.g., AB, ON, BC)
 *       - in: query
 *         name: agreement_type
 *         schema:
 *           type: string
 *           enum: [G, C, O]
 *         description: Filter by agreement type (G=Grant, C=Contribution, O=Other)
 *       - in: query
 *         name: start_date_from
 *         schema:
 *           type: string
 *           format: date
 *         description: Filter by start date (from)
 *       - in: query
 *         name: start_date_to
 *         schema:
 *           type: string
 *           format: date
 *         description: Filter by start date (to)
 *       - in: query
 *         name: value_min
 *         schema:
 *           type: number
 *         description: Filter by minimum agreement value
 *       - in: query
 *         name: value_max
 *         schema:
 *           type: number
 *         description: Filter by maximum agreement value
 *       - in: query
 *         name: program
 *         schema:
 *           type: string
 *         description: Filter by program name (partial match)
 *     responses:
 *       200:
 *         description: List of grants
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 data:
 *                   type: array
 *                   items:
 *                     $ref: '#/components/schemas/Grant'
 *                 count:
 *                   type: integer
 *                 pagination:
 *                   type: object
 *       500:
 *         $ref: '#/components/responses/ServerError'
 */
exports.getAllGrants = async (req, res, next) => {
  try {
    const {
      page, limit, offset, sort, fields,
      province, agreement_type, start_date_from, start_date_to,
      end_date_from, end_date_to, value_min, value_max,
      country, city, program
    } = req.query;

    const filters = {
      province, agreement_type, start_date_from, start_date_to,
      end_date_from, end_date_to, value_min, value_max,
      country, city, program
    };
    const options = { page, limit, offset, sort, fields };

    const result = await grantsService.getAllGrants(filters, options);

    res.json(formatSuccessResponse(result.data, {
      count: result.data.length,
      pagination: getPaginationMetadata(result.total, page, result.limit, result.offset)
    }));
  } catch (error) {
    next(error);
  }
};

/**
 * @swagger
 * /grants/{id}:
 *   get:
 *     summary: Get grant by ID
 *     tags: [Grants]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *         description: Grant ID
 *     responses:
 *       200:
 *         description: Grant details
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success: { type: boolean }
 *                 data: { $ref: '#/components/schemas/Grant' }
 *       404:
 *         $ref: '#/components/responses/NotFound'
 *       500:
 *         $ref: '#/components/responses/ServerError'
 */
exports.getGrantById = async (req, res, next) => {
  try {
    const { id } = req.params;
    const grant = await grantsService.getGrantById(id);

    if (!grant) {
      return res.status(404).json(
        formatErrorResponse('Grant not found', 'GRANT_NOT_FOUND')
      );
    }

    res.json(formatSuccessResponse(grant));
  } catch (error) {
    next(error);
  }
};

/**
 * @swagger
 * /grants/search:
 *   get:
 *     summary: Search grants by text
 *     tags: [Grants]
 *     parameters:
 *       - in: query
 *         name: q
 *         required: true
 *         schema:
 *           type: string
 *         description: Search term (searches recipient name, program name)
 *       - $ref: '#/components/parameters/limitParam'
 *       - $ref: '#/components/parameters/pageParam'
 *     responses:
 *       200:
 *         description: Search results
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success: { type: boolean }
 *                 data: { type: array }
 *                 count: { type: integer }
 *                 searchTerm: { type: string }
 *       400:
 *         $ref: '#/components/responses/BadRequest'
 *       500:
 *         $ref: '#/components/responses/ServerError'
 */
exports.searchGrants = async (req, res, next) => {
  try {
    const { q, page, limit, offset } = req.query;

    if (!q) {
      return res.status(400).json(
        formatErrorResponse('Search query required', 'MISSING_QUERY')
      );
    }

    const result = await grantsService.searchGrants(q, { page, limit, offset });

    res.json(formatSuccessResponse(result.data, {
      count: result.data.length,
      searchTerm: q,
      pagination: getPaginationMetadata(result.total, page, result.limit, result.offset)
    }));
  } catch (error) {
    next(error);
  }
};

/**
 * @swagger
 * /grants/stats:
 *   get:
 *     summary: Get grants statistics
 *     tags: [Grants]
 *     responses:
 *       200:
 *         description: Statistics about grants and contributions
 *       500:
 *         $ref: '#/components/responses/ServerError'
 */
exports.getGrantsStats = async (req, res, next) => {
  try {
    const stats = await grantsService.getGrantsStats();
    res.json(formatSuccessResponse(stats));
  } catch (error) {
    next(error);
  }
};

/**
 * @swagger
 * /grants/stats/filtered:
 *   get:
 *     summary: Get filtered grant statistics
 *     tags: [Grants]
 *     parameters:
 *       - in: query
 *         name: province
 *         schema:
 *           type: string
 *         description: Filter by province
 *       - in: query
 *         name: agreement_type
 *         schema:
 *           type: string
 *         description: Filter by agreement type
 *       - in: query
 *         name: start_date_from
 *         schema:
 *           type: string
 *           format: date
 *         description: Filter by start date (from)
 *       - in: query
 *         name: start_date_to
 *         schema:
 *           type: string
 *           format: date
 *         description: Filter by start date (to)
 *       - in: query
 *         name: value_min
 *         schema:
 *           type: number
 *         description: Filter by minimum value
 *       - in: query
 *         name: value_max
 *         schema:
 *           type: number
 *         description: Filter by maximum value
 *     responses:
 *       200:
 *         description: Filtered statistics
 *       500:
 *         $ref: '#/components/responses/ServerError'
 */
exports.getFilteredStats = async (req, res, next) => {
  try {
    const { province, agreement_type, start_date_from, start_date_to, value_min, value_max } = req.query;
    const stats = await grantsService.getFilteredStats({
      province,
      agreement_type,
      start_date_from,
      start_date_to,
      value_min,
      value_max
    });

    res.json(formatSuccessResponse(stats));
  } catch (error) {
    next(error);
  }
};

/**
 * @swagger
 * /grants/timeline:
 *   get:
 *     summary: Get grants timeline data for visualization
 *     tags: [Grants]
 *     parameters:
 *       - in: query
 *         name: province
 *         schema:
 *           type: string
 *         description: Filter by province
 *       - in: query
 *         name: agreement_type
 *         schema:
 *           type: string
 *         description: Filter by agreement type
 *       - in: query
 *         name: start_date
 *         schema:
 *           type: string
 *           format: date
 *         description: Start date for timeline
 *       - in: query
 *         name: end_date
 *         schema:
 *           type: string
 *           format: date
 *         description: End date for timeline
 *     responses:
 *       200:
 *         description: Timeline data
 *       500:
 *         $ref: '#/components/responses/ServerError'
 */
exports.getGrantsTimeline = async (req, res, next) => {
  try {
    const { province, agreement_type, start_date, end_date } = req.query;
    const timeline = await grantsService.getGrantsTimeline({
      province,
      agreement_type,
      start_date,
      end_date
    });

    res.json(formatSuccessResponse(timeline, {
      count: timeline.length
    }));
  } catch (error) {
    next(error);
  }
};

/**
 * @swagger
 * /health:
 *   get:
 *     summary: Health check endpoint
 *     tags: [Utility]
 *     responses:
 *       200:
 *         description: Service health status
 */
exports.healthCheck = async (req, res, next) => {
  try {
    const pool = require('../config/database');
    const dbCheck = await pool.query('SELECT NOW()');

    res.json({
      success: true,
      data: {
        status: 'healthy',
        timestamp: new Date().toISOString(),
        database: dbCheck.rows ? 'connected' : 'disconnected',
        uptime: process.uptime()
      }
    });
  } catch (error) {
    next(error);
  }
};
