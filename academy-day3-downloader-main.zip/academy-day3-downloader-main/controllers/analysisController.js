const analysisService = require('../services/analysisService');

/**
 * COMPREHENSIVE ANALYSIS CONTROLLER
 * Handles all analysis endpoints for SKILL4
 */

/**
 * Get executive dashboard KPIs
 */
exports.getDashboardKPIs = async (req, res) => {
  try {
    const filters = extractFilters(req.query);
    const data = await analysisService.getDashboardKPIs(filters);

    res.json({
      success: true,
      data
    });
  } catch (error) {
    console.error('Dashboard KPIs error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to retrieve dashboard KPIs',
      error: error.message
    });
  }
};

/**
 * Get financial analysis
 */
exports.getFinancialAnalysis = async (req, res) => {
  try {
    const filters = extractFilters(req.query);
    const data = await analysisService.getFinancialAnalysis(filters);

    res.json({
      success: true,
      data
    });
  } catch (error) {
    console.error('Financial analysis error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to retrieve financial analysis',
      error: error.message
    });
  }
};

/**
 * Get temporal analysis
 */
exports.getTemporalAnalysis = async (req, res) => {
  try {
    const filters = extractFilters(req.query);
    const data = await analysisService.getTemporalAnalysis(filters);

    res.json({
      success: true,
      data
    });
  } catch (error) {
    console.error('Temporal analysis error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to retrieve temporal analysis',
      error: error.message
    });
  }
};

/**
 * Get geographic analysis
 */
exports.getGeographicAnalysis = async (req, res) => {
  try {
    const filters = extractFilters(req.query);
    const data = await analysisService.getGeographicAnalysis(filters);

    res.json({
      success: true,
      data
    });
  } catch (error) {
    console.error('Geographic analysis error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to retrieve geographic analysis',
      error: error.message
    });
  }
};

/**
 * Get recipient analysis
 */
exports.getRecipientAnalysis = async (req, res) => {
  try {
    const filters = extractFilters(req.query);
    const data = await analysisService.getRecipientAnalysis(filters);

    res.json({
      success: true,
      data
    });
  } catch (error) {
    console.error('Recipient analysis error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to retrieve recipient analysis',
      error: error.message
    });
  }
};

/**
 * Get program analysis
 */
exports.getProgramAnalysis = async (req, res) => {
  try {
    const filters = extractFilters(req.query);
    const data = await analysisService.getProgramAnalysis(filters);

    res.json({
      success: true,
      data
    });
  } catch (error) {
    console.error('Program analysis error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to retrieve program analysis',
      error: error.message
    });
  }
};

/**
 * Get risk analysis
 */
exports.getRiskAnalysis = async (req, res) => {
  try {
    const filters = extractFilters(req.query);
    const data = await analysisService.getRiskAnalysis(filters);

    res.json({
      success: true,
      data
    });
  } catch (error) {
    console.error('Risk analysis error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to retrieve risk analysis',
      error: error.message
    });
  }
};

/**
 * Get equity analysis
 */
exports.getEquityAnalysis = async (req, res) => {
  try {
    const filters = extractFilters(req.query);
    const data = await analysisService.getEquityAnalysis(filters);

    res.json({
      success: true,
      data
    });
  } catch (error) {
    console.error('Equity analysis error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to retrieve equity analysis',
      error: error.message
    });
  }
};

/**
 * Get operational efficiency analysis
 */
exports.getOperationalAnalysis = async (req, res) => {
  try {
    const filters = extractFilters(req.query);
    const data = await analysisService.getOperationalAnalysis(filters);

    res.json({
      success: true,
      data
    });
  } catch (error) {
    console.error('Operational analysis error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to retrieve operational analysis',
      error: error.message
    });
  }
};

/**
 * Get data quality analysis
 */
exports.getDataQualityAnalysis = async (req, res) => {
  try {
    const filters = extractFilters(req.query);
    const data = await analysisService.getDataQualityAnalysis(filters);

    res.json({
      success: true,
      data
    });
  } catch (error) {
    console.error('Data quality analysis error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to retrieve data quality analysis',
      error: error.message
    });
  }
};

/**
 * Get anomaly detection results
 */
exports.getAnomalyDetection = async (req, res) => {
  try {
    const filters = extractFilters(req.query);
    const data = await analysisService.getAnomalyDetection(filters);

    res.json({
      success: true,
      data
    });
  } catch (error) {
    console.error('Anomaly detection error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to retrieve anomaly detection',
      error: error.message
    });
  }
};

/**
 * Get recipient profile
 */
exports.getRecipientProfile = async (req, res) => {
  try {
    const recipientName = req.params.name || req.query.name;

    if (!recipientName) {
      return res.status(400).json({
        success: false,
        message: 'Recipient name is required'
      });
    }

    const filters = extractFilters(req.query);
    const data = await analysisService.getRecipientProfile(recipientName, filters);

    if (!data) {
      return res.status(404).json({
        success: false,
        message: 'Recipient not found'
      });
    }

    res.json({
      success: true,
      data
    });
  } catch (error) {
    console.error('Recipient profile error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to retrieve recipient profile',
      error: error.message
    });
  }
};

/**
 * Extract filters from query parameters
 */
function extractFilters(query) {
  const filters = {};

  if (query.province) filters.province = query.province;
  if (query.agreement_type) filters.agreement_type = query.agreement_type;
  if (query.start_date_from) filters.start_date_from = query.start_date_from;
  if (query.start_date_to) filters.start_date_to = query.start_date_to;
  if (query.end_date_from) filters.end_date_from = query.end_date_from;
  if (query.end_date_to) filters.end_date_to = query.end_date_to;
  if (query.value_min) filters.value_min = parseFloat(query.value_min);
  if (query.value_max) filters.value_max = parseFloat(query.value_max);
  if (query.city) filters.city = query.city;
  if (query.program) filters.program = query.program;
  if (query.recipient_type) filters.recipient_type = query.recipient_type;
  if (query.owner_org) filters.owner_org = query.owner_org;
  if (query.federal_riding) filters.federal_riding = query.federal_riding;

  return filters;
}

/**
 * Get recipient search results
 */
exports.getRecipientSearch = async (req, res) => {
  try {
    const searchTerm = req.query.search || req.query.q || '';

    if (!searchTerm || searchTerm.trim().length < 2) {
      return res.status(400).json({
        success: false,
        message: 'Search term must be at least 2 characters'
      });
    }

    const filters = extractFilters(req.query);
    const data = await analysisService.getRecipientSearch(searchTerm, filters);

    res.json({
      success: true,
      data,
      search_term: searchTerm
    });
  } catch (error) {
    console.error('Recipient search error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to search recipients',
      error: error.message
    });
  }
};

module.exports = exports;
