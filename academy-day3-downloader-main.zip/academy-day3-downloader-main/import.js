require('dotenv').config();
const { Pool } = require('pg');
const fs = require('fs');
const path = require('path');
const { downloadDataset, readRecordsInBatches, getMetadata } = require('./download');

// Configuration
const BATCH_SIZE = 500;  // Records per INSERT (reduced due to large number of columns)
const DATA_DIR = path.join(__dirname, 'data');

// Database connection
const pool = new Pool({
  connectionString: process.env.DB_CONNECTION_STRING,
});

// Helper: Escape single quotes for SQL
function escapeSql(value) {
  if (value === null || value === undefined) return null;
  return String(value).replace(/'/g, "''");
}

// Helper: Clean and validate string
function cleanString(value) {
  if (!value || value === '') return null;
  return String(value).trim();
}

// Helper: Parse date with validation
function parseDate(value) {
  if (!value || value === '') return null;
  const cleaned = String(value).trim().replace(/[\r\n\t]+/g, '');
  if (cleaned.length < 8 || cleaned.length > 10) return null;
  if (!/^\d{4}[-/]\d{1,2}[-/]\d{1,2}$/.test(cleaned)) return null;
  return cleaned;
}

// Helper: Parse decimal
function parseDecimal(value) {
  if (!value || value === '') return null;
  const parsed = parseFloat(value);
  return isNaN(parsed) ? null : parsed;
}

// Helper: Parse integer
function parseInteger(value) {
  if (!value || value === '') return null;
  const parsed = parseInt(value, 10);
  return isNaN(parsed) ? null : parsed;
}

// Check if data exists for resource
function hasDataFiles(resourceId) {
  const { getBatchFiles } = require('./download');
  const batches = getBatchFiles(resourceId);
  return batches.length > 0;
}

// Ensure data is downloaded
async function ensureDataDownloaded(resourceId, datasetName) {
  if (!hasDataFiles(resourceId)) {
    console.log('📥 Data not found locally. Starting download...\n');
    await downloadDataset(resourceId, datasetName);
  } else {
    const metadata = getMetadata(resourceId);
    console.log(`✓ Found ${metadata.totalBatches} batch files with ${metadata.totalRecords.toLocaleString()} total records\n`);
  }
}

// Process row and map to database columns
function processRow(row) {
  try {
    return {
      _id: parseInteger(row._id),
      ref_number: cleanString(row.ref_number),
      amendment_number: cleanString(row.amendment_number),
      amendment_date: parseDate(row.amendment_date),
      agreement_type: cleanString(row.agreement_type),
      recipient_type: cleanString(row.recipient_type),
      recipient_business_number: cleanString(row.recipient_business_number),
      recipient_legal_name: cleanString(row.recipient_legal_name),
      recipient_operating_name: cleanString(row.recipient_operating_name),
      research_organization_name: cleanString(row.research_organization_name),
      recipient_country: cleanString(row.recipient_country),
      recipient_province: cleanString(row.recipient_province),
      recipient_city: cleanString(row.recipient_city),
      recipient_postal_code: cleanString(row.recipient_postal_code),
      federal_riding_name_en: cleanString(row.federal_riding_name_en),
      federal_riding_name_fr: cleanString(row.federal_riding_name_fr),
      federal_riding_number: cleanString(row.federal_riding_number),
      prog_name_en: cleanString(row.prog_name_en),
      prog_name_fr: cleanString(row.prog_name_fr),
      prog_purpose_en: cleanString(row.prog_purpose_en),
      prog_purpose_fr: cleanString(row.prog_purpose_fr),
      agreement_title_en: cleanString(row.agreement_title_en),
      agreement_title_fr: cleanString(row.agreement_title_fr),
      agreement_number: cleanString(row.agreement_number),
      agreement_value: parseDecimal(row.agreement_value),
      foreign_currency_type: cleanString(row.foreign_currency_type),
      foreign_currency_value: parseDecimal(row.foreign_currency_value),
      agreement_start_date: parseDate(row.agreement_start_date),
      agreement_end_date: parseDate(row.agreement_end_date),
      coverage: cleanString(row.coverage),
      description_en: cleanString(row.description_en),
      description_fr: cleanString(row.description_fr),
      naics_identifier: cleanString(row.naics_identifier),
      expected_results_en: cleanString(row.expected_results_en),
      expected_results_fr: cleanString(row.expected_results_fr),
      additional_information_en: cleanString(row.additional_information_en),
      additional_information_fr: cleanString(row.additional_information_fr),
      owner_org: cleanString(row.owner_org),
      owner_org_title: cleanString(row.owner_org_title)
    };
  } catch (error) {
    console.error(`Error processing row: ${error.message}`);
    return null;
  }
}

// Insert a batch of records
async function insertBatch(client, batch, tableName) {
  if (batch.length === 0) return 0;

  try {
    // Build VALUES clause
    const values = batch.map(row => {
      const valuesList = Object.values(row).map(val => {
        if (val === null) return 'NULL';
        if (typeof val === 'boolean') return val ? 'TRUE' : 'FALSE';
        if (typeof val === 'number') return val;
        return `'${escapeSql(val)}'`;
      }).join(', ');
      return `(${valuesList})`;
    }).join(',\n');

    // Execute batch insert
    const insertSql = `
      INSERT INTO ${tableName} (
        _id, ref_number, amendment_number, amendment_date, agreement_type,
        recipient_type, recipient_business_number, recipient_legal_name,
        recipient_operating_name, research_organization_name, recipient_country,
        recipient_province, recipient_city, recipient_postal_code,
        federal_riding_name_en, federal_riding_name_fr, federal_riding_number,
        prog_name_en, prog_name_fr, prog_purpose_en, prog_purpose_fr,
        agreement_title_en, agreement_title_fr, agreement_number,
        agreement_value, foreign_currency_type, foreign_currency_value,
        agreement_start_date, agreement_end_date, coverage,
        description_en, description_fr, naics_identifier,
        expected_results_en, expected_results_fr,
        additional_information_en, additional_information_fr,
        owner_org, owner_org_title
      )
      VALUES ${values}
      ON CONFLICT (_id) DO NOTHING
    `;

    await client.query(insertSql);
    return batch.length;
  } catch (err) {
    console.error(`  ❌ Error inserting batch: ${err.message}`);
    throw err;
  }
}

// Process and insert records from batches
async function processAndImport(client, resourceId, tableName) {
  let totalInserted = 0;
  let totalProcessed = 0;
  let skippedRows = 0;
  let currentBatch = [];

  const metadata = getMetadata(resourceId);
  const totalRecords = metadata.totalRecords;

  console.log(`📊 Starting import of ${totalRecords.toLocaleString()} records\n`);

  let batchCount = 0;
  for (const dataChunk of readRecordsInBatches(resourceId)) {
    batchCount++;
    console.log(`📦 Processing batch ${batchCount} (offset ${dataChunk.offset.toLocaleString()}, ${dataChunk.count} records)...`);

    for (const record of dataChunk.records) {
      totalProcessed++;

      try {
        const processed = processRow(record);
        if (processed && processed._id) {
          currentBatch.push(processed);

          // Insert when batch is full
          if (currentBatch.length >= BATCH_SIZE) {
            const inserted = await insertBatch(client, currentBatch, tableName);
            totalInserted += inserted;

            const percentComplete = ((totalProcessed / totalRecords) * 100).toFixed(1);
            console.log(`  ✓ Inserted ${inserted} rows | Total: ${totalInserted.toLocaleString()}/${totalRecords.toLocaleString()} (${percentComplete}%)`);

            currentBatch = [];
          }
        } else {
          skippedRows++;
        }
      } catch (err) {
        console.error(`  ⚠️  Error processing record at position ${totalProcessed}: ${err.message}`);
        skippedRows++;
      }
    }
  }

  // Insert remaining records
  if (currentBatch.length > 0) {
    const inserted = await insertBatch(client, currentBatch, tableName);
    totalInserted += inserted;
    console.log(`  ✓ Inserted final batch: ${inserted} rows`);
  }

  console.log(`\n${'='.repeat(80)}`);
  console.log(`✅ Import complete!`);
  console.log(`   Total processed: ${totalProcessed.toLocaleString()}`);
  console.log(`   Total inserted: ${totalInserted.toLocaleString()}`);
  if (skippedRows > 0) {
    console.log(`   Skipped (invalid): ${skippedRows.toLocaleString()}`);
  }
  console.log(`${'='.repeat(80)}\n`);

  return totalInserted;
}

// Import dataset
async function importDataset(resourceId, tableName) {
  console.log(`\n${'='.repeat(80)}`);
  console.log(`📥 Canada Grants Data Import`);
  console.log(`${'='.repeat(80)}\n`);

  try {
    // Ensure data is downloaded
    await ensureDataDownloaded(resourceId, 'Grants and Contributions');

    // Connect to database
    console.log('🔌 Connecting to database...');
    const client = await pool.connect();
    console.log('✓ Database connected\n');

    try {
      // Start transaction
      await client.query('BEGIN');
      console.log('🔄 Transaction started\n');

      // Import data
      await processAndImport(client, resourceId, tableName);

      // Commit transaction
      await client.query('COMMIT');
      console.log('✅ Transaction committed\n');

    } catch (error) {
      // Rollback on error
      await client.query('ROLLBACK');
      console.error('❌ Transaction rolled back due to error\n');
      throw error;
    } finally {
      client.release();
    }

  } catch (error) {
    console.error(`\n❌ Import error: ${error.message}\n`);
    throw error;
  } finally {
    await pool.end();
  }
}

// Run import
if (require.main === module) {
  const resourceId = process.argv[2];
  const tableName = process.argv[3] || 'grants_contributions';

  if (!resourceId) {
    console.error('Usage: node import.js <resource_id> [table_name]');
    console.error('Example: node import.js 1d15a62f-5656-49ad-8c88-f40ce689d831 grants_contributions');
    process.exit(1);
  }

  importDataset(resourceId, tableName).catch(err => {
    console.error('Fatal import error:', err);
    process.exit(1);
  });
}

module.exports = { importDataset };
