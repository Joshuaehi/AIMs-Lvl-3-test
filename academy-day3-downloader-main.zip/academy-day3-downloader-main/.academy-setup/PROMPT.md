
# Overview
Following SKILL1-MIGRATE.md, SKILL2-BACKEND.md, and SKILL3-FRONTEND.md, fully implement this application, ensuring that you meet all requirements.

The Steps to follow are as follows:

## Using SKILL 1-MIGRATE.md

Read and follow all instructions in SKILL1-DATA-EXTRACTOR.md.

Download this Government of Canada Open Data Portal resource:
https://open.canada.ca/data/en/api/3/action/datastore_search?resource_id=1d15a62f-5656-49ad-8c88-f40ce689d831&limit=10000&offset=0

This contains the whole of Canada's Grants and Contributions data .

## Record Specific Information
A sample of this format with the schema can be found in this file /data/sample.json which explains the schema.
Specifically examine the results.records array with 39 attributes. 
Note also the fields array with various metadata which describes the schema for this data such as:

```json
"id": "ref_number",
"type": "text",
"info": {
    "notes_fr": "",
    "notes_en": "",
    "label_en": "Reference Number",
    "label_fr": "Num\u00e9ro de r\u00e9f\u00e9rence",
    "type_override": ""
}
```        
Follow the instructions in Skill 1 and fully implement the data download and the upload to the Postgres database.

## Using SKILL2-BACKEND

After the first step is completed, we will proceed to Step 2, which is to build the backend.

We will build this all out in /app/backend/

Follow all instructions in SKILL2-BACKEND.md.

Using the migrate.js and the import.js files as reference, build a comprehensive Node.js Express application to serve this new data. We need a comprehensive controller and router to enable read capabilities, with specific endpoints for search and filter which will be critical when the frontend is implemented. Anticipate the needs of the frontend in this regard.

## Using SKILL3-FRONTEND

After the second step is completed, we will proceed to Step 3, which is to build the frontend.

Follow all instructions in SKILL3-FRONTEND.md.

Within the Vue.js front-end application, build a comprehensive interface to interact with this data served from the Node.js Express backend.

Specifically, I need filters and views which enable us to look at Alberta companies.
We need filtering by the date, value, program/purpose, agreement type (Grant or Contribution).
Specifically we need to be able to search by name, and visualize this information in table, gantt style chart, and graph.

## End Result
At the end, I should have a fully working app which I can run 'npm install' and 'npm start' and open this application and begin interacting with the data immediately.

