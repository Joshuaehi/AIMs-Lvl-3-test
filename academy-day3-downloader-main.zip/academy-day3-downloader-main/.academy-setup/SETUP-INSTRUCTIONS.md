# Setup Instructions

## Prerequisites

1. **Node.js** v14 or higher (v16+ recommended)
2. **PostgreSQL** v12 or higher (v14+ recommended)
3. **npm** (comes with Node.js)

## Step-by-Step Setup

### 1. Install Dependencies

```bash
npm install
```

### 2. Configure Database

Create a PostgreSQL database:

```sql
CREATE DATABASE canada_grants;
```

### 3. Configure Environment Variables

Copy the example environment file and edit it:

```bash
cp .env.example .env
```

Edit `.env` and update the `DB_CONNECTION_STRING`:

```env
DB_CONNECTION_STRING=postgresql://username:password@localhost:5432/canada_grants
PORT=3000
NODE_ENV=development
API_VERSION=v1
```

Replace `username` and `password` with your PostgreSQL credentials.

### 4. Download and Import Data

**Option A: Automatic (Recommended)**

The import script will automatically download data if not cached:

```bash
npm run migrate
npm run import
```

**Option B: Manual**

Download data first, then import:

```bash
npm run download
npm run migrate
npm run import
```

This process will:
- Download 1.2M+ records from the Canada Open Data Portal
- Cache the data locally in `/data/` directory
- Create the database schema
- Import all records (this may take 10-20 minutes)

### 5. Start the Application

```bash
npm start
```

The server will start on http://localhost:3000

### 6. Access the Application

- **Frontend**: http://localhost:3000
- **API Documentation**: http://localhost:3000/api-docs
- **Health Check**: http://localhost:3000/api/v1/health
- **Database Stats**: http://localhost:3000/api/v1/stats

## Troubleshooting

### Database Connection Issues

If you get connection errors:
1. Verify PostgreSQL is running
2. Check your connection string in `.env`
3. Ensure the database exists
4. Verify your username and password

### Port Already in Use

If port 3000 is already in use, change it in `.env`:

```env
PORT=3001
```

### Data Import Slow

The initial data import of 1.2M records takes time. Progress is shown in the console.
You can reduce the batch size in `import.js` if you encounter memory issues.

### Memory Issues

If you encounter memory issues during import:
1. Close other applications
2. Reduce `BATCH_SIZE` in `import.js` (default is 500)
3. Increase Node.js memory: `node --max-old-space-size=4096 import.js`

## Features Overview

### Frontend Features
- **Alberta Focus**: Quick filter button for Alberta grants
- **Advanced Filtering**: Province, type, date range, value range
- **Search**: Full-text search by recipient name
- **Table View**: Comprehensive listing with pagination
- **Detail View**: Full grant information
- **Visualizations**:
  - Province distribution bar chart
  - Grant type pie chart
  - Gantt-style timeline showing grant durations
- **Dark Mode**: Toggle between light and dark themes
- **Responsive**: Mobile-friendly design

### API Features
- **RESTful Endpoints**: Full CRUD operations
- **Advanced Filtering**: Multiple filter parameters
- **Full-Text Search**: Search by recipient name and program
- **Pagination**: Efficient data retrieval
- **Swagger Documentation**: Interactive API docs
- **Statistics**: Database statistics and aggregations
- **Timeline Data**: For Gantt chart visualization

## Development

For development with auto-reload:

```bash
npm run dev
```

This requires `nodemon` to be installed (included in devDependencies).

## Data Source

Data is sourced from the Government of Canada Open Data Portal:
- Resource ID: `1d15a62f-5656-49ad-8c88-f40ce689d831`
- Dataset: Grants and Contributions
- Total Records: 1,258,580+
- Updated: Regularly by the Government of Canada

## Support

For issues or questions:
1. Check the API documentation at `/api-docs`
2. Review the README.md
3. Check console logs for error details
