# Quick Start Guide

## Get Started in 5 Minutes

### 1. Install Dependencies (1 minute)
```bash
npm install
```

### 2. Configure Database (1 minute)
Create a PostgreSQL database and update `.env`:

```bash
cp .env.example .env
# Edit .env with your database credentials
```

Example `.env`:
```env
DB_CONNECTION_STRING=postgresql://postgres:password@localhost:5432/canada_grants
PORT=3000
NODE_ENV=development
API_VERSION=v1
```

### 3. Setup Database and Import Data (15-20 minutes)
```bash
npm run migrate
npm run import
```

This will:
- Download 1.2M+ records from Canada Open Data Portal
- Create database schema with indexes
- Import all records in batches

### 4. Start the Application (10 seconds)
```bash
npm start
```

### 5. Open Your Browser
- **Frontend**: http://localhost:3000
- **API Docs**: http://localhost:3000/api-docs

## What You Can Do

### Explore Alberta Grants
1. Click **"Alberta Grants"** button on home page
2. View all grants and contributions for Alberta companies
3. Filter by date range, value, or type

### Search by Company Name
1. Use the search bar in List view
2. Enter company name (e.g., "Canadian")
3. Press Enter to search

### View Data Visualizations
1. Click **"Visualizations"** button
2. See province distribution charts
3. View Gantt-style timeline of grant durations

### Filter by Multiple Criteria
1. Select province (e.g., Alberta)
2. Choose grant type (Grant or Contribution)
3. Set date range (e.g., 2020-01-01 to 2023-12-31)
4. Set value range (e.g., $100,000 to $1,000,000)
5. View filtered results

## Key Features

✅ **1.2M+ Grant Records** - Complete Canada grants database
✅ **Alberta Focus** - Quick access to Alberta companies
✅ **Advanced Filtering** - Province, type, dates, values
✅ **Search** - Find grants by recipient name
✅ **Table View** - Comprehensive listing with pagination
✅ **Gantt Chart** - Visual timeline of grant durations
✅ **Charts** - Province and type distribution graphs
✅ **Dark Mode** - Toggle light/dark theme
✅ **Mobile Responsive** - Works on all devices
✅ **REST API** - Full API with Swagger documentation

## API Quick Reference

### Get All Grants
```bash
curl "http://localhost:3000/api/v1/grants?limit=10"
```

### Filter by Alberta
```bash
curl "http://localhost:3000/api/v1/grants?province=AB&limit=10"
```

### Search by Name
```bash
curl "http://localhost:3000/api/v1/grants/search?q=University&limit=10"
```

### Get Statistics
```bash
curl "http://localhost:3000/api/v1/stats"
```

### Get Timeline Data
```bash
curl "http://localhost:3000/api/v1/grants/timeline?province=AB"
```

## Troubleshooting

### Database Connection Error
- Check PostgreSQL is running: `pg_ctl status`
- Verify credentials in `.env`
- Ensure database exists: `psql -l`

### Port Already in Use
Change port in `.env`:
```env
PORT=3001
```

### Import Taking Too Long
This is normal! Importing 1.2M records takes 15-20 minutes.
Watch the console for progress updates.

## Next Steps

1. Read `SETUP-INSTRUCTIONS.md` for detailed setup
2. Read `FEATURES.md` for complete feature list
3. Explore `/api-docs` for API documentation
4. Check `README.md` for project overview

## Need Help?

- Check console logs for errors
- Review API documentation at `/api-docs`
- Ensure all dependencies are installed
- Verify database connection string

---

**Enjoy exploring Canada's Grants and Contributions data!** 🇨🇦
