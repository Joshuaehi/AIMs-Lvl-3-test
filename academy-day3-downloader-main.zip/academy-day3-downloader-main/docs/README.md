# Canada Grants and Contributions Explorer

Full-stack application for exploring Canada's Grants and Contributions data from the Government of Canada Open Data Portal.

## Quick Start

1. **Install dependencies**:
   ```bash
   npm install
   ```

2. **Configure environment**:
   ```bash
   cp .env.example .env
   # Edit .env with your PostgreSQL database credentials
   ```

3. **Download data** (optional - will download automatically on first import):
   ```bash
   npm run download
   ```

4. **Set up database**:
   ```bash
   npm run migrate
   npm run import
   ```

5. **Start server**:
   ```bash
   npm start
   ```

6. **Access application**:
   - Frontend: http://localhost:3000
   - API Documentation: http://localhost:3000/api-docs
   - Health Check: http://localhost:3000/api/v1/health

## Features

- **Comprehensive API**: RESTful endpoints with full CRUD operations
- **Advanced Filtering**: Filter by province (especially Alberta), date range, value, agreement type
- **Full-Text Search**: Search grants by recipient name
- **Data Visualization**: Table view, Gantt chart, and graphs
- **Responsive Design**: Mobile-friendly interface with dark mode
- **Interactive Documentation**: Swagger UI for API exploration

## API Endpoints

- `GET /api/v1/grants` - List all grants with pagination and filters
- `GET /api/v1/grants/:id` - Get specific grant details
- `GET /api/v1/grants/search` - Search grants by text
- `GET /api/v1/stats` - Database statistics
- `GET /api/v1/health` - Health check

## Tech Stack

- **Backend**: Node.js, Express.js, PostgreSQL
- **Frontend**: Vue.js 3 (CDN), Tailwind CSS
- **Documentation**: Swagger/OpenAPI
- **Data Source**: Government of Canada Open Data Portal

## Data Schema

Contains 1.2M+ records with 39 fields including:
- Recipient information (name, location, business number)
- Agreement details (type, value, dates)
- Program information (name, purpose)
- Descriptions in English and French

## License

MIT
