# Features Documentation

## Complete Feature List

### 1. Data Migration (SKILL1)

#### Download Script (`download.js`)
- Fetches data from Canada Open Data Portal API
- Handles pagination (10,000 records per request)
- Caches data locally to avoid repeated downloads
- Progress tracking and error handling
- Total dataset: 1.2M+ grant and contribution records

#### Schema Analysis (`analyze-schema.js`)
- Automatic field type detection
- Sample data analysis (1,000 records)
- PostgreSQL type mapping
- Field statistics (null counts, max lengths)

#### Migration Script (`migrate.js`)
- Creates `grants_contributions` table with 39 fields
- Appropriate data types for each field
- Primary key on `_id`
- Indexes for performance:
  - Province (for Alberta filtering)
  - Agreement type
  - Start/end dates
  - Full-text search on recipient name
  - Full-text search on program name
  - Agreement value

#### Import Script (`import.js`)
- Batch import (500 records per batch)
- Data validation and cleaning
- Handles NULL values properly
- Date and decimal parsing
- ON CONFLICT handling for idempotency
- Progress tracking
- Error logging

### 2. Backend API (SKILL2)

#### Core Infrastructure
- **Express.js**: Web framework
- **PostgreSQL**: Database with connection pooling
- **CORS**: Enabled for frontend access
- **Helmet**: Security headers
- **Morgan**: Request logging
- **Swagger**: Interactive API documentation

#### API Endpoints

##### Grants Endpoints
- `GET /api/v1/grants` - List all grants with filtering
  - Query params: province, agreement_type, start_date_from, start_date_to, value_min, value_max, program
  - Pagination: page, limit, offset
  - Sorting: sort parameter
  - Field selection: fields parameter

- `GET /api/v1/grants/:id` - Get specific grant by ID

- `GET /api/v1/grants/search` - Full-text search
  - Searches: recipient name, program name
  - Pagination support

- `GET /api/v1/grants/stats` - Statistics
  - Total grants and contributions
  - Total values and averages
  - Distribution by province
  - Distribution by type

- `GET /api/v1/grants/timeline` - Timeline data for Gantt chart
  - Filterable by province, type, dates
  - Returns up to 500 grants with date ranges

##### Utility Endpoints
- `GET /api/v1/health` - Health check
- `GET /api-docs` - Swagger UI
- `GET /api-docs.json` - OpenAPI specification

#### Query Features
- **Pagination**: Configurable page size (max 1000)
- **Sorting**: Ascending/descending on any field
- **Field Selection**: Return only requested fields
- **Advanced Filtering**: Multiple criteria with AND logic
- **Full-Text Search**: PostgreSQL full-text search
- **Response Format**: Consistent JSON structure

#### Performance Optimizations
- Database connection pooling
- Indexed queries
- Batch processing
- Efficient pagination
- Field selection to reduce payload

### 3. Frontend Application (SKILL3)

#### Technology Stack
- **Vue.js 3**: Reactive framework (CDN)
- **Tailwind CSS**: Utility-first CSS (CDN)
- **Axios**: HTTP client (CDN)
- **Chart.js**: Data visualization (CDN)
- Single-file application in `/public/index.html`

#### Views

##### Home View
- Welcome banner
- Statistics cards:
  - Total grants count and value
  - Grants (Type G) count
  - Contributions (Type C) count
  - Average grant value
- Quick action buttons:
  - Alberta Grants (filters to AB)
  - Browse All
  - Visualizations

##### List View
- **Search Bar**: Search by recipient name
- **Filters**:
  - Province dropdown (all Canadian provinces, **Alberta highlighted**)
  - Agreement Type (Grant/Contribution/Other)
  - Start Date From/To (date pickers)
  - Min/Max Value (number inputs)
  - Per Page (25/50/100)
- **Data Table**:
  - Recipient name
  - Location (city, province)
  - Type badge (color-coded)
  - Value (formatted as CAD)
  - Date range
  - Program name
  - View details button
- **Pagination**:
  - Previous/Next buttons
  - Page numbers
  - Records count display
- **Clear Filters** button

##### Detail View
- Back to list navigation
- **Recipient Information**:
  - Legal name
  - City, province, postal code
  - Business number
- **Agreement Details**:
  - Type (Grant/Contribution/Other)
  - Value (large, formatted)
  - Start and end dates
  - Reference number
- **Program Information**:
  - Program name (English/French)
  - Description
  - Expected results
  - Additional information

##### Visualizations View
- **Timeline Filters**:
  - Province selector
  - Agreement type selector
  - Start/end date pickers
- **Charts**:
  - **Province Distribution**: Bar chart showing top 10 provinces by grant count
  - **Grant Type Distribution**: Pie chart showing grants vs contributions
- **Gantt Timeline**:
  - Horizontal timeline bars
  - Color-coded by type (green=grant, blue=contribution)
  - Shows grant duration (start to end date)
  - Displays recipient name and value
  - Hover tooltips
  - Shows up to 20 grants
  - Scales dynamically based on date range

#### UI Features
- **Dark Mode**: Toggle with persistent preference
- **Responsive Design**: Mobile, tablet, and desktop layouts
- **Loading States**: Spinner overlay during API calls
- **Error Handling**: User-friendly error messages
- **Empty States**: Helpful messages when no data
- **Smooth Transitions**: Fade and slide animations
- **Custom Scrollbar**: Styled for light/dark modes

#### Alberta-Specific Features
- Quick filter button on home page
- Province dropdown defaults to showing Alberta
- Easy one-click access to Alberta grants
- All filtering capabilities work with Alberta selection

### 4. Data Visualization Features

#### Table Visualization
- Sortable columns
- Filterable data
- Paginated results
- Color-coded type badges
- Responsive layout
- Mobile card view

#### Gantt Chart Visualization
- Timeline bars showing grant duration
- Start and end dates visualized
- Color-coded by agreement type
- Scaled to fit date range
- Hover tooltips with details
- Recipient names displayed
- Value shown on bars

#### Graph Visualizations
- **Bar Chart**: Grants by province (top 10)
- **Pie Chart**: Distribution by type (Grant/Contribution)
- Interactive charts with Chart.js
- Responsive and mobile-friendly
- Dark mode compatible

### 5. Additional Features

#### Caching
- Local data caching to avoid repeated API downloads
- Frontend localStorage for dark mode preference

#### Error Handling
- Graceful API error handling
- User-friendly error messages
- Console logging for debugging
- Validation of user inputs

#### Performance
- Indexed database queries
- Batch data processing
- Efficient pagination
- Field selection
- Connection pooling

#### Security
- Helmet security headers
- CORS configuration
- SQL injection prevention (parameterized queries)
- Input validation

#### Documentation
- Comprehensive README
- Setup instructions
- API documentation (Swagger)
- Inline code comments
- Feature documentation

## Usage Examples

### Finding Alberta Grants
1. Click "Alberta Grants" on home page
2. Or navigate to Browse All and select "AB" from province dropdown
3. Optionally filter by date range, value, or type

### Searching by Company Name
1. Enter company name in search bar
2. Press Enter or click search button
3. Results show matching recipients

### Viewing Grant Timeline
1. Navigate to Visualizations
2. Select filters (e.g., Alberta, specific date range)
3. View Gantt chart showing grant durations
4. Hover over bars for details

### Filtering by Value Range
1. In List view, enter minimum value (e.g., 100000)
2. Enter maximum value (e.g., 500000)
3. Click apply or press Enter
4. View grants within that value range

### Analyzing Provincial Distribution
1. Navigate to Visualizations
2. View "Grants by Province" bar chart
3. See which provinces receive most grants
4. View "Grants by Type" pie chart for type distribution
