const express = require('express');
const router = express.Router();
const grantsController = require('../controllers/grantsController');

/**
 * @swagger
 * tags:
 *   name: Grants
 *   description: Grants and contributions management endpoints
 */

// Search and stats routes come before parameterized routes
router.get('/search', grantsController.searchGrants);
router.get('/stats', grantsController.getGrantsStats);
router.get('/stats/filtered', grantsController.getFilteredStats);
router.get('/timeline', grantsController.getGrantsTimeline);

// Main CRUD routes
router.get('/', grantsController.getAllGrants);
router.get('/:id', grantsController.getGrantById);

module.exports = router;
