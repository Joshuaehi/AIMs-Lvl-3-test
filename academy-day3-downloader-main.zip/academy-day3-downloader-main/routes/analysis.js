const express = require('express');
const router = express.Router();
const analysisController = require('../controllers/analysisController');

/**
 * @swagger
 * tags:
 *   name: Analysis
 *   description: Comprehensive grant program analysis endpoints following SKILL4 framework
 */

/**
 * @swagger
 * components:
 *   parameters:
 *     provinceParam:
 *       in: query
 *       name: province
 *       schema:
 *         type: string
 *         example: AB
 *       description: Filter by province code (e.g., AB, ON, BC)
 *     agreementTypeParam:
 *       in: query
 *       name: agreement_type
 *       schema:
 *         type: string
 *         enum: [G, C, O]
 *       description: Filter by agreement type (G=Grant, C=Contribution, O=Other)
 *     startDateFromParam:
 *       in: query
 *       name: start_date_from
 *       schema:
 *         type: string
 *         format: date
 *         example: "2023-01-01"
 *       description: Filter by start date from (inclusive)
 *     startDateToParam:
 *       in: query
 *       name: start_date_to
 *       schema:
 *         type: string
 *         format: date
 *         example: "2023-12-31"
 *       description: Filter by start date to (inclusive)
 *     valueMinParam:
 *       in: query
 *       name: value_min
 *       schema:
 *         type: number
 *         example: 100000
 *       description: Filter by minimum agreement value
 *     valueMaxParam:
 *       in: query
 *       name: value_max
 *       schema:
 *         type: number
 *         example: 5000000
 *       description: Filter by maximum agreement value
 *     cityParam:
 *       in: query
 *       name: city
 *       schema:
 *         type: string
 *         example: Calgary
 *       description: Filter by city name (partial match)
 *     programParam:
 *       in: query
 *       name: program
 *       schema:
 *         type: string
 *       description: Filter by program name (partial match)
 *     recipientTypeParam:
 *       in: query
 *       name: recipient_type
 *       schema:
 *         type: string
 *       description: Filter by recipient type
 *     searchTermParam:
 *       in: query
 *       name: search
 *       required: true
 *       schema:
 *         type: string
 *         minLength: 2
 *         example: University
 *       description: Search term (minimum 2 characters)
 */

/**
 * @swagger
 * /analysis/dashboard:
 *   get:
 *     summary: Get executive dashboard KPIs
 *     description: Returns high-level key performance indicators for grant programs including total agreements, unique recipients, funding totals, and activity metrics.
 *     tags: [Analysis]
 *     parameters:
 *       - $ref: '#/components/parameters/provinceParam'
 *       - $ref: '#/components/parameters/agreementTypeParam'
 *       - $ref: '#/components/parameters/startDateFromParam'
 *       - $ref: '#/components/parameters/startDateToParam'
 *       - $ref: '#/components/parameters/valueMinParam'
 *       - $ref: '#/components/parameters/valueMaxParam'
 *     responses:
 *       200:
 *         description: Dashboard KPIs retrieved successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 data:
 *                   type: object
 *                   properties:
 *                     total_agreements:
 *                       type: integer
 *                       example: 116107
 *                     unique_recipients:
 *                       type: integer
 *                       example: 37740
 *                     total_funding:
 *                       type: number
 *                       example: 67555799416.04
 *                     active_agreements:
 *                       type: integer
 *                       example: 15234
 *                     program_count:
 *                       type: integer
 *                       example: 387
 *                     department_count:
 *                       type: integer
 *                       example: 42
 *                     amendment_rate:
 *                       type: string
 *                       example: "18.45"
 *                     average_value:
 *                       type: number
 *                       example: 581829.76
 *       500:
 *         $ref: '#/components/responses/ServerError'
 */
router.get('/dashboard', analysisController.getDashboardKPIs);

/**
 * @swagger
 * /analysis/financial:
 *   get:
 *     summary: Get comprehensive financial analysis
 *     description: Returns financial metrics including value distribution, concentration analysis (HHI), value tiers, top recipients, and anomaly detection (round numbers, threshold gaming).
 *     tags: [Analysis]
 *     parameters:
 *       - $ref: '#/components/parameters/provinceParam'
 *       - $ref: '#/components/parameters/agreementTypeParam'
 *       - $ref: '#/components/parameters/startDateFromParam'
 *       - $ref: '#/components/parameters/startDateToParam'
 *       - $ref: '#/components/parameters/valueMinParam'
 *       - $ref: '#/components/parameters/valueMaxParam'
 *     responses:
 *       200:
 *         description: Financial analysis retrieved successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   type: object
 *                   properties:
 *                     overview:
 *                       type: object
 *                       description: Overall financial statistics
 *                     by_tier:
 *                       type: array
 *                       description: Distribution by value tier (Micro/Small/Medium/Large/Major/Mega)
 *                     by_type:
 *                       type: array
 *                       description: Distribution by agreement type
 *                     top_recipients:
 *                       type: array
 *                       description: Top 20 recipients by funding
 *                     concentration:
 *                       type: object
 *                       description: HHI index and concentration metrics
 *                     anomalies:
 *                       type: object
 *                       description: Round number and threshold gaming detection
 *       500:
 *         $ref: '#/components/responses/ServerError'
 */
router.get('/financial', analysisController.getFinancialAnalysis);

/**
 * @swagger
 * /analysis/temporal:
 *   get:
 *     summary: Get temporal analysis
 *     description: Returns time-based analysis including fiscal year trends, quarterly distribution, Q4 spending patterns, March fiscal year-end analysis, project durations, and amendment rates.
 *     tags: [Analysis]
 *     parameters:
 *       - $ref: '#/components/parameters/provinceParam'
 *       - $ref: '#/components/parameters/agreementTypeParam'
 *       - $ref: '#/components/parameters/startDateFromParam'
 *       - $ref: '#/components/parameters/startDateToParam'
 *     responses:
 *       200:
 *         description: Temporal analysis retrieved successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   type: object
 *                   properties:
 *                     by_fiscal_year:
 *                       type: array
 *                       description: Spending by fiscal year
 *                     by_quarter:
 *                       type: array
 *                       description: Spending by fiscal quarter (Q1-Q4)
 *                     by_month:
 *                       type: array
 *                       description: Monthly spending patterns
 *                     q4_analysis:
 *                       type: array
 *                       description: Q4 spending ratio analysis (fiscal year-end)
 *                     duration_analysis:
 *                       type: object
 *                       description: Project duration statistics
 *                     amendment_analysis:
 *                       type: object
 *                       description: Amendment frequency metrics
 *       500:
 *         $ref: '#/components/responses/ServerError'
 */
router.get('/temporal', analysisController.getTemporalAnalysis);

/**
 * @swagger
 * /analysis/geographic:
 *   get:
 *     summary: Get geographic analysis
 *     description: Returns spatial distribution of funding including city-level analysis, federal riding distribution, urban/rural classification, and postal code patterns.
 *     tags: [Analysis]
 *     parameters:
 *       - $ref: '#/components/parameters/provinceParam'
 *       - $ref: '#/components/parameters/agreementTypeParam'
 *       - $ref: '#/components/parameters/cityParam'
 *     responses:
 *       200:
 *         description: Geographic analysis retrieved successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   type: object
 *                   properties:
 *                     by_city:
 *                       type: array
 *                       description: Top 50 cities by funding
 *                     by_riding:
 *                       type: array
 *                       description: Distribution by federal riding
 *                     urban_rural:
 *                       type: array
 *                       description: Urban vs rural classification
 *                     metrics:
 *                       type: object
 *                       description: Urban/rural ratio and metro share
 *       500:
 *         $ref: '#/components/responses/ServerError'
 */
router.get('/geographic', analysisController.getGeographicAnalysis);

/**
 * @swagger
 * /analysis/recipients:
 *   get:
 *     summary: Get recipient analysis
 *     description: Returns recipient concentration patterns, repeat recipient analysis, new vs returning recipients, and multi-program participation metrics.
 *     tags: [Analysis]
 *     parameters:
 *       - $ref: '#/components/parameters/provinceParam'
 *       - $ref: '#/components/parameters/agreementTypeParam'
 *       - $ref: '#/components/parameters/recipientTypeParam'
 *     responses:
 *       200:
 *         description: Recipient analysis retrieved successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   type: object
 *                   properties:
 *                     overview:
 *                       type: object
 *                       description: Overall recipient statistics
 *                     repeat_analysis:
 *                       type: object
 *                       description: One-time vs repeat recipient breakdown
 *                     top_recipients:
 *                       type: array
 *                       description: Top 50 recipients with detailed metrics
 *                     by_type:
 *                       type: array
 *                       description: Distribution by recipient type
 *                     new_vs_returning:
 *                       type: array
 *                       description: New vs returning recipients by year
 *       500:
 *         $ref: '#/components/responses/ServerError'
 */
router.get('/recipients', analysisController.getRecipientAnalysis);

/**
 * @swagger
 * /analysis/programs:
 *   get:
 *     summary: Get program analysis
 *     description: Returns program effectiveness metrics, continuity analysis, data quality assessment, and department program counts.
 *     tags: [Analysis]
 *     parameters:
 *       - $ref: '#/components/parameters/provinceParam'
 *       - $ref: '#/components/parameters/agreementTypeParam'
 *       - $ref: '#/components/parameters/programParam'
 *     responses:
 *       200:
 *         description: Program analysis retrieved successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   type: object
 *                   properties:
 *                     programs:
 *                       type: array
 *                       description: Top 100 programs with metrics
 *                     by_department:
 *                       type: array
 *                       description: Program count by department
 *                     continuity:
 *                       type: array
 *                       description: Program continuity (years active)
 *                     data_quality:
 *                       type: object
 *                       description: Description and expected results completion rates
 *       500:
 *         $ref: '#/components/responses/ServerError'
 */
router.get('/programs', analysisController.getProgramAnalysis);

/**
 * @swagger
 * /analysis/risk:
 *   get:
 *     summary: Get risk analysis
 *     description: Returns risk assessment including high-value agreements, fiscal year-end timing risks, data completeness scoring, high amendment recipients, and duration anomalies.
 *     tags: [Analysis]
 *     parameters:
 *       - $ref: '#/components/parameters/provinceParam'
 *       - $ref: '#/components/parameters/agreementTypeParam'
 *       - $ref: '#/components/parameters/valueMinParam'
 *     responses:
 *       200:
 *         description: Risk analysis retrieved successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   type: object
 *                   properties:
 *                     high_value_agreements:
 *                       type: array
 *                       description: Agreements over $1M
 *                     fiscal_year_end_risk:
 *                       type: object
 *                       description: March agreement statistics
 *                     data_completeness_risk:
 *                       type: object
 *                       description: Missing field analysis
 *                     high_amendment_recipients:
 *                       type: array
 *                       description: Recipients with >40% amendment rate
 *                     duration_risks:
 *                       type: object
 *                       description: Short high-value and very long duration counts
 *       500:
 *         $ref: '#/components/responses/ServerError'
 */
router.get('/risk', analysisController.getRiskAnalysis);

/**
 * @swagger
 * /analysis/equity:
 *   get:
 *     summary: Get equity and access analysis
 *     description: Returns equity metrics including organization size distribution, geographic equity, recipient type equity, and first-time access patterns.
 *     tags: [Analysis]
 *     parameters:
 *       - $ref: '#/components/parameters/provinceParam'
 *       - $ref: '#/components/parameters/cityParam'
 *       - $ref: '#/components/parameters/recipientTypeParam'
 *     responses:
 *       200:
 *         description: Equity analysis retrieved successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   type: object
 *                   properties:
 *                     organization_size_equity:
 *                       type: object
 *                       description: Small/medium/large organization funding shares
 *                     geographic_equity:
 *                       type: array
 *                       description: Metro/urban/rural distribution
 *                     recipient_type_equity:
 *                       type: array
 *                       description: Funding by recipient type
 *                     first_time_access_by_region:
 *                       type: array
 *                       description: New recipients by geographic classification
 *       500:
 *         $ref: '#/components/responses/ServerError'
 */
router.get('/equity', analysisController.getEquityAnalysis);

/**
 * @swagger
 * /analysis/operational:
 *   get:
 *     summary: Get operational efficiency analysis
 *     description: Returns efficiency metrics including multi-year vs annual ratios, program transaction volumes, renewal patterns, and consolidation opportunities.
 *     tags: [Analysis]
 *     parameters:
 *       - $ref: '#/components/parameters/provinceParam'
 *       - $ref: '#/components/parameters/programParam'
 *     responses:
 *       200:
 *         description: Operational efficiency analysis retrieved successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   type: object
 *                   properties:
 *                     program_efficiency:
 *                       type: array
 *                       description: Programs with efficiency indicators
 *                     multi_year_analysis:
 *                       type: object
 *                       description: Multi-year vs annual agreement ratio
 *                     renewal_patterns:
 *                       type: object
 *                       description: Consistent recipient renewal statistics
 *                     administrative_burden:
 *                       type: array
 *                       description: Recipients with many small agreements
 *       500:
 *         $ref: '#/components/responses/ServerError'
 */
router.get('/operational', analysisController.getOperationalAnalysis);

/**
 * @swagger
 * /analysis/data-quality:
 *   get:
 *     summary: Get data quality assessment
 *     description: Returns data completeness metrics, field-by-field completion rates, department quality comparison, and consistency checks.
 *     tags: [Analysis]
 *     parameters:
 *       - $ref: '#/components/parameters/provinceParam'
 *     responses:
 *       200:
 *         description: Data quality assessment retrieved successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   type: object
 *                   properties:
 *                     overview:
 *                       type: object
 *                       properties:
 *                         total_records:
 *                           type: integer
 *                         weighted_quality_score:
 *                           type: string
 *                         quality_grade:
 *                           type: string
 *                           enum: [A, B, C, D, F]
 *                     field_completeness:
 *                       type: object
 *                       description: Completion rate for each field
 *                     by_department:
 *                       type: array
 *                       description: Quality metrics by department
 *                     consistency_checks:
 *                       type: object
 *                       description: Invalid date, value, and postal code counts
 *       500:
 *         $ref: '#/components/responses/ServerError'
 */
router.get('/data-quality', analysisController.getDataQualityAnalysis);

/**
 * @swagger
 * /analysis/anomalies:
 *   get:
 *     summary: Get anomaly detection and alerts
 *     description: Returns automated anomaly detection including statistical outliers (z-score >3), threshold gaming, concentration alerts, rapid projects, and fiscal year-end rush patterns.
 *     tags: [Analysis]
 *     parameters:
 *       - $ref: '#/components/parameters/provinceParam'
 *       - $ref: '#/components/parameters/agreementTypeParam'
 *       - $ref: '#/components/parameters/valueMinParam'
 *     responses:
 *       200:
 *         description: Anomaly detection completed successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   type: object
 *                   properties:
 *                     statistical_outliers:
 *                       type: object
 *                       properties:
 *                         count:
 *                           type: integer
 *                         severity:
 *                           type: string
 *                           enum: [Low, Medium, High]
 *                         items:
 *                           type: array
 *                           description: Agreements with z-score > 3
 *                     threshold_gaming:
 *                       type: object
 *                       description: Values just below reporting thresholds
 *                     concentration_alerts:
 *                       type: object
 *                       description: Single recipient >25% of program
 *                     rapid_projects:
 *                       type: object
 *                       description: High value with <30 day duration
 *                     fiscal_year_end_rush:
 *                       type: object
 *                       description: Agreements starting in late March
 *                     summary:
 *                       type: object
 *                       properties:
 *                         total_alerts:
 *                           type: integer
 *                         by_severity:
 *                           type: object
 *       500:
 *         $ref: '#/components/responses/ServerError'
 */
router.get('/anomalies', analysisController.getAnomalyDetection);

/**
 * @swagger
 * /analysis/search:
 *   get:
 *     summary: Search recipients with comprehensive analysis
 *     description: Wildcard search across recipient names, business numbers, and organization names with year-over-year analysis and detailed grant listings.
 *     tags: [Analysis]
 *     parameters:
 *       - $ref: '#/components/parameters/searchTermParam'
 *       - $ref: '#/components/parameters/provinceParam'
 *       - $ref: '#/components/parameters/agreementTypeParam'
 *       - $ref: '#/components/parameters/startDateFromParam'
 *       - $ref: '#/components/parameters/startDateToParam'
 *       - $ref: '#/components/parameters/valueMinParam'
 *       - $ref: '#/components/parameters/valueMaxParam'
 *       - $ref: '#/components/parameters/cityParam'
 *     responses:
 *       200:
 *         description: Recipient search completed successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 search_term:
 *                   type: string
 *                 data:
 *                   type: object
 *                   properties:
 *                     matching_recipients:
 *                       type: array
 *                       description: Top 50 matching recipients with totals
 *                     grants:
 *                       type: array
 *                       description: Up to 1000 detailed grant records
 *                     year_over_year:
 *                       type: array
 *                       description: Fiscal year breakdown with trends
 *                     summary:
 *                       type: object
 *                       properties:
 *                         total_grants:
 *                           type: integer
 *                         total_value:
 *                           type: number
 *                         unique_recipients:
 *                           type: integer
 *                         unique_programs:
 *                           type: integer
 *                         date_range:
 *                           type: object
 *       400:
 *         $ref: '#/components/responses/BadRequest'
 *       500:
 *         $ref: '#/components/responses/ServerError'
 */
router.get('/search', analysisController.getRecipientSearch);

/**
 * @swagger
 * /analysis/recipient/{name}:
 *   get:
 *     summary: Get detailed recipient profile
 *     description: Returns comprehensive profile for a specific recipient including funding history, program participation, department relationships, and amendment patterns.
 *     tags: [Analysis]
 *     parameters:
 *       - in: path
 *         name: name
 *         required: true
 *         schema:
 *           type: string
 *         description: Recipient legal name
 *         example: University of Calgary
 *       - $ref: '#/components/parameters/provinceParam'
 *     responses:
 *       200:
 *         description: Recipient profile retrieved successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   type: object
 *                   properties:
 *                     recipient_info:
 *                       type: object
 *                       description: Basic recipient information
 *                     funding_summary:
 *                       type: object
 *                       description: Total funding statistics
 *                     agreement_history:
 *                       type: array
 *                       description: All agreements for this recipient
 *                     program_participation:
 *                       type: array
 *                       description: Programs and departments funded by
 *       404:
 *         $ref: '#/components/responses/NotFound'
 *       500:
 *         $ref: '#/components/responses/ServerError'
 */
router.get('/recipient/:name', analysisController.getRecipientProfile);

/**
 * @swagger
 * /analysis/recipient:
 *   get:
 *     summary: Get detailed recipient profile by query parameter
 *     description: Alternative endpoint for recipient profile using query parameter instead of path parameter.
 *     tags: [Analysis]
 *     parameters:
 *       - in: query
 *         name: name
 *         required: true
 *         schema:
 *           type: string
 *         description: Recipient legal name
 *         example: University of Calgary
 *       - $ref: '#/components/parameters/provinceParam'
 *     responses:
 *       200:
 *         description: Recipient profile retrieved successfully
 *       404:
 *         $ref: '#/components/responses/NotFound'
 *       500:
 *         $ref: '#/components/responses/ServerError'
 */
router.get('/recipient', analysisController.getRecipientProfile);

module.exports = router;
