const express = require('express');
const router = express.Router();
const grantsController = require('../controllers/grantsController');

// Import all route modules
const grantsRoutes = require('./grants');
const analysisRoutes = require('./analysis');

// Register routes
router.use('/grants', grantsRoutes);
router.use('/analysis', analysisRoutes);

// Utility endpoints
router.get('/health', grantsController.healthCheck);
router.get('/stats', grantsController.getGrantsStats);

module.exports = router;
